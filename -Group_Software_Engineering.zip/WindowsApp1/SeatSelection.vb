﻿Public Class SeatSelection
    Dim greyIcon As New System.Drawing.Bitmap(My.Resources.grey)
    Dim redIcon As New System.Drawing.Bitmap(My.Resources.red)
    Dim greenIcon As New System.Drawing.Bitmap(My.Resources.green)
    Dim delIcon As New System.Drawing.Bitmap(My.Resources.del)


    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim c As Control

        For Each c In Me.Controls
            If TypeOf (c) Is PictureBox Then
                CType(c, PictureBox).Image = greyIcon
                pictureBox44.Image = redIcon
                pictureBox28.Image = redIcon
                pictureBox18.Image = redIcon
                pictureBox17.Image = redIcon
                pictureBox14.Image = redIcon
                pictureBox1.Image = redIcon
                pictureBox40.Image = redIcon
                pictureBox98.Image = redIcon
                pictureBox51.Image = redIcon
                pictureBox52.Image = redIcon
                pictureBox67.Image = redIcon
                pictureBox84.Image = redIcon
                pictureBox83.Image = redIcon
                pictureBox82.Image = redIcon

                AddHandler c.Click, AddressOf pictureBox7_Click

            End If
        Next
    End Sub

    Private Sub pictureBox7_Click(sender As Object, e As EventArgs)
        Static cout As Integer = 0
        If CType(sender, PictureBox).Image Is greyIcon Then
            CType(sender, PictureBox).Image = greenIcon
            cout += 1
            TextBox2.Text = cout.ToString("")
        ElseIf CType(sender, PictureBox).Image Is greenIcon Then
            CType(sender, PictureBox).Image = greyIcon
            cout -= 1
            TextBox2.Text = cout.ToString("")
        ElseIf CType(sender, PictureBox).Image Is redIcon Then
            MsgBox("This seat has been booked!", MsgBoxStyle.Information + MsgBoxStyle.OkOnly, "Message Box")
        End If
    End Sub

    Private Sub button1_Click_1(sender As Object, e As EventArgs) Handles button1.Click
        SeatManage.Show()
    End Sub
End Class
