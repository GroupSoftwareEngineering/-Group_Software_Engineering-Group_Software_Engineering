﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class SearchMovie
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(SearchMovie))
        Dim ListViewItem19 As System.Windows.Forms.ListViewItem = New System.Windows.Forms.ListViewItem(New String() {"1917 (2014)"}, 0, System.Drawing.Color.White, System.Drawing.Color.Empty, New System.Drawing.Font("Bahnschrift Condensed", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte)))
        Dim ListViewItem20 As System.Windows.Forms.ListViewItem = New System.Windows.Forms.ListViewItem(New String() {"007: No Time To Die"}, 160, System.Drawing.Color.White, System.Drawing.Color.Empty, New System.Drawing.Font("Bahnschrift Condensed", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte)))
        Dim ListViewItem21 As System.Windows.Forms.ListViewItem = New System.Windows.Forms.ListViewItem(New String() {"FURY (2014)"}, 21, System.Drawing.Color.White, System.Drawing.Color.Empty, New System.Drawing.Font("Bahnschrift Condensed", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte)))
        Dim ListViewItem22 As System.Windows.Forms.ListViewItem = New System.Windows.Forms.ListViewItem(New String() {"AQUAMAN (2018)"}, 4, System.Drawing.Color.White, System.Drawing.Color.Empty, New System.Drawing.Font("Bahnschrift Condensed", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte)))
        Dim ListViewItem23 As System.Windows.Forms.ListViewItem = New System.Windows.Forms.ListViewItem(New String() {"BIRDS OF PREY (2020)"}, 9, System.Drawing.Color.White, System.Drawing.Color.Empty, New System.Drawing.Font("Bahnschrift Condensed", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte)))
        Dim ListViewItem24 As System.Windows.Forms.ListViewItem = New System.Windows.Forms.ListViewItem(New String() {"BLACK WIDOW (2021)"}, 10, System.Drawing.Color.White, System.Drawing.Color.Empty, New System.Drawing.Font("Bahnschrift Condensed", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte)))
        Dim ListViewItem25 As System.Windows.Forms.ListViewItem = New System.Windows.Forms.ListViewItem(New String() {"BRAVEN (2018)"}, 57, System.Drawing.Color.White, System.Drawing.Color.Empty, New System.Drawing.Font("Bahnschrift Condensed", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte)))
        Dim ListViewItem26 As System.Windows.Forms.ListViewItem = New System.Windows.Forms.ListViewItem(New String() {"BUMBLEE BEE (2018)"}, 11, System.Drawing.Color.White, System.Drawing.Color.Empty, New System.Drawing.Font("Bahnschrift Condensed", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte)))
        Dim ListViewItem27 As System.Windows.Forms.ListViewItem = New System.Windows.Forms.ListViewItem(New String() {"CAPTAIN AMERICA (2016)"}, 12, System.Drawing.Color.White, System.Drawing.Color.Empty, New System.Drawing.Font("Bahnschrift Condensed", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte)))
        Dim ListViewItem28 As System.Windows.Forms.ListViewItem = New System.Windows.Forms.ListViewItem(New String() {"REVENGE (2017)"}, 97, System.Drawing.Color.White, System.Drawing.Color.Empty, New System.Drawing.Font("Bahnschrift Condensed", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte)))
        Dim ListViewItem29 As System.Windows.Forms.ListViewItem = New System.Windows.Forms.ListViewItem(New String() {"DIVERGENT (2014)"}, 15, System.Drawing.Color.White, System.Drawing.Color.Empty, New System.Drawing.Font("Bahnschrift Condensed", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte)))
        Dim ListViewItem30 As System.Windows.Forms.ListViewItem = New System.Windows.Forms.ListViewItem(New String() {"IRON MAN 3 (2013)"}, 24, System.Drawing.Color.White, System.Drawing.Color.Empty, New System.Drawing.Font("Bahnschrift Condensed", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte)))
        Dim ListViewItem31 As System.Windows.Forms.ListViewItem = New System.Windows.Forms.ListViewItem(New String() {"LOGAN (2017)"}, 28, System.Drawing.Color.White, System.Drawing.Color.Empty, New System.Drawing.Font("Bahnschrift Condensed", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte)))
        Dim ListViewItem32 As System.Windows.Forms.ListViewItem = New System.Windows.Forms.ListViewItem(New String() {"SKYSCRAPER (2018)"}, 36, System.Drawing.Color.White, System.Drawing.Color.Empty, New System.Drawing.Font("Bahnschrift Condensed", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte)))
        Dim ListViewItem33 As System.Windows.Forms.ListViewItem = New System.Windows.Forms.ListViewItem(New String() {"STAR WARS (2019)"}, 38, System.Drawing.Color.White, System.Drawing.Color.Empty, New System.Drawing.Font("Bahnschrift Condensed", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte)))
        Dim ListViewItem34 As System.Windows.Forms.ListViewItem = New System.Windows.Forms.ListViewItem(New String() {"THOR (2013)"}, 42, System.Drawing.Color.White, System.Drawing.Color.Empty, New System.Drawing.Font("Bahnschrift Condensed", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte)))
        Dim ListViewItem35 As System.Windows.Forms.ListViewItem = New System.Windows.Forms.ListViewItem(New String() {"VENOM (2018)"}, 45, System.Drawing.Color.White, System.Drawing.Color.Empty, New System.Drawing.Font("Bahnschrift Condensed", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte)))
        Dim ListViewItem36 As System.Windows.Forms.ListViewItem = New System.Windows.Forms.ListViewItem("")
        Me.btnCancel = New System.Windows.Forms.Button()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.btnSearch = New System.Windows.Forms.PictureBox()
        Me.txtMovie = New System.Windows.Forms.TextBox()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.btnOk = New System.Windows.Forms.Button()
        Me.lblNo = New System.Windows.Forms.Label()
        Me.MovieList = New System.Windows.Forms.ImageList(Me.components)
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.colImage = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.colName = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.LVAction = New System.Windows.Forms.ListView()
        CType(Me.btnSearch, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel1.SuspendLayout()
        Me.Panel3.SuspendLayout()
        Me.SuspendLayout()
        '
        'btnCancel
        '
        Me.btnCancel.BackColor = System.Drawing.Color.DarkRed
        Me.btnCancel.Font = New System.Drawing.Font("LEMON MILK", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnCancel.ForeColor = System.Drawing.Color.White
        Me.btnCancel.Location = New System.Drawing.Point(612, 5)
        Me.btnCancel.Name = "btnCancel"
        Me.btnCancel.Size = New System.Drawing.Size(30, 30)
        Me.btnCancel.TabIndex = 59
        Me.btnCancel.Text = "X"
        Me.btnCancel.UseVisualStyleBackColor = False
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Font = New System.Drawing.Font("LEMON MILK", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.ForeColor = System.Drawing.Color.White
        Me.Label10.Location = New System.Drawing.Point(188, 28)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(253, 43)
        Me.Label10.TabIndex = 54
        Me.Label10.Text = "Search Movie"
        '
        'btnSearch
        '
        Me.btnSearch.Image = CType(resources.GetObject("btnSearch.Image"), System.Drawing.Image)
        Me.btnSearch.Location = New System.Drawing.Point(446, 80)
        Me.btnSearch.Name = "btnSearch"
        Me.btnSearch.Size = New System.Drawing.Size(30, 30)
        Me.btnSearch.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.btnSearch.TabIndex = 53
        Me.btnSearch.TabStop = False
        '
        'txtMovie
        '
        Me.txtMovie.Font = New System.Drawing.Font("Bahnschrift", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtMovie.ForeColor = System.Drawing.Color.Black
        Me.txtMovie.Location = New System.Drawing.Point(184, 84)
        Me.txtMovie.Name = "txtMovie"
        Me.txtMovie.Size = New System.Drawing.Size(256, 26)
        Me.txtMovie.TabIndex = 52
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.DarkRed
        Me.Panel1.Controls.Add(Me.btnCancel)
        Me.Panel1.Controls.Add(Me.Label10)
        Me.Panel1.Controls.Add(Me.btnSearch)
        Me.Panel1.Controls.Add(Me.txtMovie)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel1.Location = New System.Drawing.Point(0, 0)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(637, 144)
        Me.Panel1.TabIndex = 59
        '
        'btnOk
        '
        Me.btnOk.BackColor = System.Drawing.Color.DarkRed
        Me.btnOk.Font = New System.Drawing.Font("LEMON MILK", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnOk.ForeColor = System.Drawing.Color.White
        Me.btnOk.Location = New System.Drawing.Point(253, 318)
        Me.btnOk.Name = "btnOk"
        Me.btnOk.Size = New System.Drawing.Size(122, 48)
        Me.btnOk.TabIndex = 61
        Me.btnOk.Text = "OK"
        Me.btnOk.UseVisualStyleBackColor = False
        Me.btnOk.Visible = False
        '
        'lblNo
        '
        Me.lblNo.Font = New System.Drawing.Font("Bahnschrift Condensed", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblNo.ForeColor = System.Drawing.Color.DarkRed
        Me.lblNo.Location = New System.Drawing.Point(-5, 38)
        Me.lblNo.Name = "lblNo"
        Me.lblNo.Size = New System.Drawing.Size(647, 367)
        Me.lblNo.TabIndex = 60
        Me.lblNo.Text = "Sorry server is down" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Please try again!"
        Me.lblNo.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.lblNo.Visible = False
        '
        'MovieList
        '
        Me.MovieList.ImageStream = CType(resources.GetObject("MovieList.ImageStream"), System.Windows.Forms.ImageListStreamer)
        Me.MovieList.TransparentColor = System.Drawing.Color.Transparent
        Me.MovieList.Images.SetKeyName(0, "1917.jpg")
        Me.MovieList.Images.SetKeyName(1, "A Quiet Place.jpg")
        Me.MovieList.Images.SetKeyName(2, "Aladdin.jpg")
        Me.MovieList.Images.SetKeyName(3, "Alien.jpg")
        Me.MovieList.Images.SetKeyName(4, "Aquaman.jpg")
        Me.MovieList.Images.SetKeyName(5, "Avengers Infinity War.jpg")
        Me.MovieList.Images.SetKeyName(6, "Avengers Endgame.jpg")
        Me.MovieList.Images.SetKeyName(7, "Baywatch.jpg")
        Me.MovieList.Images.SetKeyName(8, "Beauty and the Beast.jpg")
        Me.MovieList.Images.SetKeyName(9, "Birds of Prey.jpg")
        Me.MovieList.Images.SetKeyName(10, "Black Widow (2021).jpg")
        Me.MovieList.Images.SetKeyName(11, "Bumble Bee.jpg")
        Me.MovieList.Images.SetKeyName(12, "Captain America.jpg")
        Me.MovieList.Images.SetKeyName(13, "Coco.jpg")
        Me.MovieList.Images.SetKeyName(14, "Crawl.jpg")
        Me.MovieList.Images.SetKeyName(15, "Divergent.jpg")
        Me.MovieList.Images.SetKeyName(16, "Doctor Strange.jpg")
        Me.MovieList.Images.SetKeyName(17, "Dora.jpg")
        Me.MovieList.Images.SetKeyName(18, "Dumbo.jpg")
        Me.MovieList.Images.SetKeyName(19, "Fantastic Beasts.jpg")
        Me.MovieList.Images.SetKeyName(20, "Finding Dory.jpg")
        Me.MovieList.Images.SetKeyName(21, "Fury.jpg")
        Me.MovieList.Images.SetKeyName(22, "Guardians of the Galaxy.jpg")
        Me.MovieList.Images.SetKeyName(23, "Interstellar.jpg")
        Me.MovieList.Images.SetKeyName(24, "Iron Man 3.jpg")
        Me.MovieList.Images.SetKeyName(25, "ironman wallpaper.jpg")
        Me.MovieList.Images.SetKeyName(26, "Joker.jpg")
        Me.MovieList.Images.SetKeyName(27, "Lion King.jpg")
        Me.MovieList.Images.SetKeyName(28, "Logan.jpg")
        Me.MovieList.Images.SetKeyName(29, "Mary Poppins.jpg")
        Me.MovieList.Images.SetKeyName(30, "Midsommar.jpg")
        Me.MovieList.Images.SetKeyName(31, "Moana.jpg")
        Me.MovieList.Images.SetKeyName(32, "Onward.jpg")
        Me.MovieList.Images.SetKeyName(33, "Parasite.jpg")
        Me.MovieList.Images.SetKeyName(34, "Raw.jpg")
        Me.MovieList.Images.SetKeyName(35, "Saw.jpg")
        Me.MovieList.Images.SetKeyName(36, "SKYSCRAPER.jpg")
        Me.MovieList.Images.SetKeyName(37, "Small Foot.jpg")
        Me.MovieList.Images.SetKeyName(38, "Star Wars.jpg")
        Me.MovieList.Images.SetKeyName(39, "Tall Grass.jpg")
        Me.MovieList.Images.SetKeyName(40, "The Greatest Showman.jpg")
        Me.MovieList.Images.SetKeyName(41, "The Wild.jpg")
        Me.MovieList.Images.SetKeyName(42, "Thor.jpg")
        Me.MovieList.Images.SetKeyName(43, "Titanic.jpg")
        Me.MovieList.Images.SetKeyName(44, "Us.jpg")
        Me.MovieList.Images.SetKeyName(45, "Venom.jpg")
        Me.MovieList.Images.SetKeyName(46, "0.0 MHz (2019).jpg")
        Me.MovieList.Images.SetKeyName(47, "22 Jump Street.jpg")
        Me.MovieList.Images.SetKeyName(48, "47 Meters Down (2019).jpg")
        Me.MovieList.Images.SetKeyName(49, "A Christmas Carol (2018).jpg")
        Me.MovieList.Images.SetKeyName(50, "A Star is Born.jpg")
        Me.MovieList.Images.SetKeyName(51, "Abominable.jpg")
        Me.MovieList.Images.SetKeyName(52, "Anchorman.jpg")
        Me.MovieList.Images.SetKeyName(53, "Be With You.jpg")
        Me.MovieList.Images.SetKeyName(54, "Before We Go.jpg")
        Me.MovieList.Images.SetKeyName(55, "Big Hero 6.jpg")
        Me.MovieList.Images.SetKeyName(56, "Brave.jpg")
        Me.MovieList.Images.SetKeyName(57, "Braven (2018).jpg")
        Me.MovieList.Images.SetKeyName(58, "Candy Cane Christmas (2020).jpg")
        Me.MovieList.Images.SetKeyName(59, "Cargo (2017).jpg")
        Me.MovieList.Images.SetKeyName(60, "Christmas under the Stars.jpg")
        Me.MovieList.Images.SetKeyName(61, "Comic 8.jpg")
        Me.MovieList.Images.SetKeyName(62, "Countdown (2019).jpg")
        Me.MovieList.Images.SetKeyName(63, "Crazy Rich Asian.jpg")
        Me.MovieList.Images.SetKeyName(64, "Critical Eleven (2017).jpg")
        Me.MovieList.Images.SetKeyName(65, "Danur (2017).jpg")
        Me.MovieList.Images.SetKeyName(66, "Dread Out.jpg")
        Me.MovieList.Images.SetKeyName(67, "Dua Garis Biru (2019).jpg")
        Me.MovieList.Images.SetKeyName(68, "Escape Room.jpg")
        Me.MovieList.Images.SetKeyName(69, "Every Day.jpg")
        Me.MovieList.Images.SetKeyName(70, "Five Feet Apart.jpg")
        Me.MovieList.Images.SetKeyName(71, "Game Night.jpg")
        Me.MovieList.Images.SetKeyName(72, "Hangout (2016).jpg")
        Me.MovieList.Images.SetKeyName(73, "Hearts of Winter (2020).jpg")
        Me.MovieList.Images.SetKeyName(74, "Hunger (2009).jpg")
        Me.MovieList.Images.SetKeyName(75, "I Spit on Your Grave 3 (2015).jpg")
        Me.MovieList.Images.SetKeyName(76, "Inception.jpg")
        Me.MovieList.Images.SetKeyName(77, "Incredibles 2.jpg")
        Me.MovieList.Images.SetKeyName(78, "Infamous.jpg")
        Me.MovieList.Images.SetKeyName(79, "Inside Out.jpg")
        Me.MovieList.Images.SetKeyName(80, "Inside.jpg")
        Me.MovieList.Images.SetKeyName(81, "Insidious (2010).jpg")
        Me.MovieList.Images.SetKeyName(82, "Insidious 3.jpg")
        Me.MovieList.Images.SetKeyName(83, "Jack the Gaint Slayer.jpg")
        Me.MovieList.Images.SetKeyName(84, "Knives Out.jpg")
        Me.MovieList.Images.SetKeyName(85, "La Llorona.jpg")
        Me.MovieList.Images.SetKeyName(86, "Me before you.jpg")
        Me.MovieList.Images.SetKeyName(87, "Midnight Sun.jpg")
        Me.MovieList.Images.SetKeyName(88, "Monster House (2006).jpg")
        Me.MovieList.Images.SetKeyName(89, "Night at the Museum.jpg")
        Me.MovieList.Images.SetKeyName(90, "Onward (2020).jpg")
        Me.MovieList.Images.SetKeyName(91, "Orphan.jpg")
        Me.MovieList.Images.SetKeyName(92, "Panic Room.jpg")
        Me.MovieList.Images.SetKeyName(93, "Pee Mak.jpg")
        Me.MovieList.Images.SetKeyName(94, "Ratatouille.jpg")
        Me.MovieList.Images.SetKeyName(95, "Ready or Not.jpg")
        Me.MovieList.Images.SetKeyName(96, "Resurreccion (2015).jpg")
        Me.MovieList.Images.SetKeyName(97, "Revenge (2017).jpg")
        Me.MovieList.Images.SetKeyName(98, "Rise of the Guardians (2012).jpg")
        Me.MovieList.Images.SetKeyName(99, "Scary Movie 2.jpg")
        Me.MovieList.Images.SetKeyName(100, "Spiderman Into the Spider-Verse.jpg")
        Me.MovieList.Images.SetKeyName(101, "Start Wars Mandalorian.jpg")
        Me.MovieList.Images.SetKeyName(102, "Still Born (2017).jpg")
        Me.MovieList.Images.SetKeyName(103, "Tangled.jpg")
        Me.MovieList.Images.SetKeyName(104, "The Age of Adaline.jpg")
        Me.MovieList.Images.SetKeyName(105, "The Assent.jpg")
        Me.MovieList.Images.SetKeyName(106, "The Best of Me (2014).jpg")
        Me.MovieList.Images.SetKeyName(107, "The Boxtrolls (2014).jpg")
        Me.MovieList.Images.SetKeyName(108, "The Boy 2 (2019).jpg")
        Me.MovieList.Images.SetKeyName(109, "The Christmas Bow.jpg")
        Me.MovieList.Images.SetKeyName(110, "The Conjuring 3 (2021).jpg")
        Me.MovieList.Images.SetKeyName(111, "The Croods.jpg")
        Me.MovieList.Images.SetKeyName(112, "The Deep End (2017).jpg")
        Me.MovieList.Images.SetKeyName(113, "The Kissing Booth 2.jpg")
        Me.MovieList.Images.SetKeyName(114, "The Kissing Booth.jpg")
        Me.MovieList.Images.SetKeyName(115, "The Nun.jpg")
        Me.MovieList.Images.SetKeyName(116, "The Platform (2019).jpg")
        Me.MovieList.Images.SetKeyName(117, "The Princess and the Frog.jpg")
        Me.MovieList.Images.SetKeyName(118, "The School.jpg")
        Me.MovieList.Images.SetKeyName(119, "The Scientist.jpg")
        Me.MovieList.Images.SetKeyName(120, "The Secret of Kells.jpg")
        Me.MovieList.Images.SetKeyName(121, "The Sleeping Room (2014).jpg")
        Me.MovieList.Images.SetKeyName(122, "The Spiderwick Chronicles (2008).jpg")
        Me.MovieList.Images.SetKeyName(123, "Tintin (2011).jpg")
        Me.MovieList.Images.SetKeyName(124, "Train to Busan.jpg")
        Me.MovieList.Images.SetKeyName(125, "Turbo.jpg")
        Me.MovieList.Images.SetKeyName(126, "Up.jpg")
        Me.MovieList.Images.SetKeyName(127, "Warkop DKI Reborn (2017).jpg")
        Me.MovieList.Images.SetKeyName(128, "Wiro Sableng 212.jpg")
        Me.MovieList.Images.SetKeyName(129, "Yes Man.jpg")
        Me.MovieList.Images.SetKeyName(130, "Zombieland.jpg")
        Me.MovieList.Images.SetKeyName(131, "Zootopia.jpg")
        Me.MovieList.Images.SetKeyName(132, "AD ASTRA (2018).jpg")
        Me.MovieList.Images.SetKeyName(133, "Annihilation (2018).jpg")
        Me.MovieList.Images.SetKeyName(134, "Avatar.jpg")
        Me.MovieList.Images.SetKeyName(135, "CODE 8 (2019).jpg")
        Me.MovieList.Images.SetKeyName(136, "JOHN CARTER (2012).jpg")
        Me.MovieList.Images.SetKeyName(137, "OBLIVION (2013).jpg")
        Me.MovieList.Images.SetKeyName(138, "OUTLANDER (2008).jpg")
        Me.MovieList.Images.SetKeyName(139, "Prometheus (2012).jpg")
        Me.MovieList.Images.SetKeyName(140, "RIDDICK (2013).jpg")
        Me.MovieList.Images.SetKeyName(141, "SUPER 8 (2011).jpg")
        Me.MovieList.Images.SetKeyName(142, "TENET (2020).jpg")
        Me.MovieList.Images.SetKeyName(143, "THE LAST DAY ON MARS (2013).jpg")
        Me.MovieList.Images.SetKeyName(144, "THE THING (2011).jpg")
        Me.MovieList.Images.SetKeyName(145, "BODY CAM (2020).jpg")
        Me.MovieList.Images.SetKeyName(146, "COHERENCE (2013).jpg")
        Me.MovieList.Images.SetKeyName(147, "FROM HELL (2001).jpg")
        Me.MovieList.Images.SetKeyName(148, "GONE GIRL (2014).jpg")
        Me.MovieList.Images.SetKeyName(149, "LOST GIRLS (2020).jpg")
        Me.MovieList.Images.SetKeyName(150, "MURDER MYSTERY (2019).jpg")
        Me.MovieList.Images.SetKeyName(151, "ROOM (2019).jpg")
        Me.MovieList.Images.SetKeyName(152, "SEARCHING (2018).jpg")
        Me.MovieList.Images.SetKeyName(153, "SHUTTER ISLAND (2010).jpg")
        Me.MovieList.Images.SetKeyName(154, "SIGNED, SEALED, DELIVERED (2014).jpg")
        Me.MovieList.Images.SetKeyName(155, "THE DA VINCI CODE (2006).jpg")
        Me.MovieList.Images.SetKeyName(156, "THE DOUBLE (2013).jpg")
        Me.MovieList.Images.SetKeyName(157, "THE GAME.jpg")
        Me.MovieList.Images.SetKeyName(158, "TRIANGLE (2009).jpg")
        Me.MovieList.Images.SetKeyName(159, "ZODIAC (2007).jpg")
        Me.MovieList.Images.SetKeyName(160, "No Time To Die.jpg")
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("LEMON MILK", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.White
        Me.Label1.Location = New System.Drawing.Point(222, 6)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(186, 29)
        Me.Label1.TabIndex = 55
        Me.Label1.Text = "Only at Cinema"
        '
        'Panel3
        '
        Me.Panel3.BackColor = System.Drawing.Color.DarkRed
        Me.Panel3.Controls.Add(Me.Label1)
        Me.Panel3.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.Panel3.Location = New System.Drawing.Point(0, 405)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(637, 48)
        Me.Panel3.TabIndex = 57
        '
        'LVAction
        '
        Me.LVAction.BackColor = System.Drawing.Color.Black
        Me.LVAction.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.colImage, Me.colName})
        Me.LVAction.HideSelection = False
        Me.LVAction.Items.AddRange(New System.Windows.Forms.ListViewItem() {ListViewItem19, ListViewItem20, ListViewItem21, ListViewItem22, ListViewItem23, ListViewItem24, ListViewItem25, ListViewItem26, ListViewItem27, ListViewItem28, ListViewItem29, ListViewItem30, ListViewItem31, ListViewItem32, ListViewItem33, ListViewItem34, ListViewItem35, ListViewItem36})
        Me.LVAction.LargeImageList = Me.MovieList
        Me.LVAction.Location = New System.Drawing.Point(0, 139)
        Me.LVAction.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.LVAction.Name = "LVAction"
        Me.LVAction.Size = New System.Drawing.Size(670, 266)
        Me.LVAction.TabIndex = 58
        Me.LVAction.UseCompatibleStateImageBehavior = False
        '
        'SearchMovie
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(637, 453)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.btnOk)
        Me.Controls.Add(Me.lblNo)
        Me.Controls.Add(Me.LVAction)
        Me.Controls.Add(Me.Panel3)
        Me.Name = "SearchMovie"
        Me.Text = "SearchMovie"
        CType(Me.btnSearch, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.Panel3.ResumeLayout(False)
        Me.Panel3.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents btnCancel As Button
    Friend WithEvents Label10 As Label
    Friend WithEvents btnSearch As PictureBox
    Friend WithEvents txtMovie As TextBox
    Friend WithEvents Panel1 As Panel
    Friend WithEvents btnOk As Button
    Friend WithEvents lblNo As Label
    Friend WithEvents MovieList As ImageList
    Friend WithEvents Label1 As Label
    Friend WithEvents Panel3 As Panel
    Friend WithEvents colImage As ColumnHeader
    Friend WithEvents colName As ColumnHeader
    Friend WithEvents LVAction As ListView
End Class
