﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class SeatManage
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(SeatManage))
        Me.PictureBox100 = New System.Windows.Forms.PictureBox()
        Me.PictureBox99 = New System.Windows.Forms.PictureBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.button4 = New System.Windows.Forms.Button()
        Me.pictureBox92 = New System.Windows.Forms.PictureBox()
        Me.pictureBox93 = New System.Windows.Forms.PictureBox()
        Me.pictureBox94 = New System.Windows.Forms.PictureBox()
        Me.pictureBox95 = New System.Windows.Forms.PictureBox()
        Me.pictureBox96 = New System.Windows.Forms.PictureBox()
        Me.pictureBox97 = New System.Windows.Forms.PictureBox()
        Me.pictureBox98 = New System.Windows.Forms.PictureBox()
        Me.pictureBox22 = New System.Windows.Forms.PictureBox()
        Me.pictureBox23 = New System.Windows.Forms.PictureBox()
        Me.pictureBox24 = New System.Windows.Forms.PictureBox()
        Me.pictureBox25 = New System.Windows.Forms.PictureBox()
        Me.pictureBox26 = New System.Windows.Forms.PictureBox()
        Me.pictureBox27 = New System.Windows.Forms.PictureBox()
        Me.pictureBox28 = New System.Windows.Forms.PictureBox()
        Me.pictureBox64 = New System.Windows.Forms.PictureBox()
        Me.pictureBox65 = New System.Windows.Forms.PictureBox()
        Me.pictureBox66 = New System.Windows.Forms.PictureBox()
        Me.pictureBox67 = New System.Windows.Forms.PictureBox()
        Me.pictureBox68 = New System.Windows.Forms.PictureBox()
        Me.pictureBox69 = New System.Windows.Forms.PictureBox()
        Me.pictureBox70 = New System.Windows.Forms.PictureBox()
        Me.pictureBox71 = New System.Windows.Forms.PictureBox()
        Me.pictureBox72 = New System.Windows.Forms.PictureBox()
        Me.pictureBox73 = New System.Windows.Forms.PictureBox()
        Me.pictureBox74 = New System.Windows.Forms.PictureBox()
        Me.pictureBox75 = New System.Windows.Forms.PictureBox()
        Me.pictureBox76 = New System.Windows.Forms.PictureBox()
        Me.pictureBox77 = New System.Windows.Forms.PictureBox()
        Me.pictureBox78 = New System.Windows.Forms.PictureBox()
        Me.pictureBox79 = New System.Windows.Forms.PictureBox()
        Me.pictureBox80 = New System.Windows.Forms.PictureBox()
        Me.pictureBox81 = New System.Windows.Forms.PictureBox()
        Me.pictureBox82 = New System.Windows.Forms.PictureBox()
        Me.pictureBox83 = New System.Windows.Forms.PictureBox()
        Me.pictureBox84 = New System.Windows.Forms.PictureBox()
        Me.pictureBox85 = New System.Windows.Forms.PictureBox()
        Me.pictureBox86 = New System.Windows.Forms.PictureBox()
        Me.pictureBox87 = New System.Windows.Forms.PictureBox()
        Me.pictureBox88 = New System.Windows.Forms.PictureBox()
        Me.pictureBox89 = New System.Windows.Forms.PictureBox()
        Me.pictureBox90 = New System.Windows.Forms.PictureBox()
        Me.pictureBox91 = New System.Windows.Forms.PictureBox()
        Me.pictureBox1 = New System.Windows.Forms.PictureBox()
        Me.pictureBox2 = New System.Windows.Forms.PictureBox()
        Me.pictureBox3 = New System.Windows.Forms.PictureBox()
        Me.pictureBox4 = New System.Windows.Forms.PictureBox()
        Me.pictureBox5 = New System.Windows.Forms.PictureBox()
        Me.pictureBox6 = New System.Windows.Forms.PictureBox()
        Me.pictureBox7 = New System.Windows.Forms.PictureBox()
        Me.pictureBox8 = New System.Windows.Forms.PictureBox()
        Me.pictureBox9 = New System.Windows.Forms.PictureBox()
        Me.pictureBox10 = New System.Windows.Forms.PictureBox()
        Me.pictureBox11 = New System.Windows.Forms.PictureBox()
        Me.pictureBox12 = New System.Windows.Forms.PictureBox()
        Me.pictureBox13 = New System.Windows.Forms.PictureBox()
        Me.pictureBox14 = New System.Windows.Forms.PictureBox()
        Me.pictureBox15 = New System.Windows.Forms.PictureBox()
        Me.pictureBox16 = New System.Windows.Forms.PictureBox()
        Me.pictureBox17 = New System.Windows.Forms.PictureBox()
        Me.pictureBox18 = New System.Windows.Forms.PictureBox()
        Me.pictureBox19 = New System.Windows.Forms.PictureBox()
        Me.pictureBox20 = New System.Windows.Forms.PictureBox()
        Me.pictureBox21 = New System.Windows.Forms.PictureBox()
        Me.pictureBox48 = New System.Windows.Forms.PictureBox()
        Me.button3 = New System.Windows.Forms.Button()
        Me.button2 = New System.Windows.Forms.Button()
        Me.label34 = New System.Windows.Forms.Label()
        Me.button1 = New System.Windows.Forms.Button()
        Me.label27 = New System.Windows.Forms.Label()
        Me.label28 = New System.Windows.Forms.Label()
        Me.label29 = New System.Windows.Forms.Label()
        Me.label30 = New System.Windows.Forms.Label()
        Me.label31 = New System.Windows.Forms.Label()
        Me.label32 = New System.Windows.Forms.Label()
        Me.label33 = New System.Windows.Forms.Label()
        Me.label26 = New System.Windows.Forms.Label()
        Me.label25 = New System.Windows.Forms.Label()
        Me.label24 = New System.Windows.Forms.Label()
        Me.label23 = New System.Windows.Forms.Label()
        Me.label22 = New System.Windows.Forms.Label()
        Me.label21 = New System.Windows.Forms.Label()
        Me.label20 = New System.Windows.Forms.Label()
        Me.label13 = New System.Windows.Forms.Label()
        Me.label14 = New System.Windows.Forms.Label()
        Me.label15 = New System.Windows.Forms.Label()
        Me.label16 = New System.Windows.Forms.Label()
        Me.label17 = New System.Windows.Forms.Label()
        Me.label18 = New System.Windows.Forms.Label()
        Me.label19 = New System.Windows.Forms.Label()
        Me.label12 = New System.Windows.Forms.Label()
        Me.label11 = New System.Windows.Forms.Label()
        Me.label10 = New System.Windows.Forms.Label()
        Me.label9 = New System.Windows.Forms.Label()
        Me.label8 = New System.Windows.Forms.Label()
        Me.label7 = New System.Windows.Forms.Label()
        Me.label6 = New System.Windows.Forms.Label()
        Me.pictureBox50 = New System.Windows.Forms.PictureBox()
        Me.pictureBox51 = New System.Windows.Forms.PictureBox()
        Me.pictureBox52 = New System.Windows.Forms.PictureBox()
        Me.pictureBox53 = New System.Windows.Forms.PictureBox()
        Me.pictureBox54 = New System.Windows.Forms.PictureBox()
        Me.pictureBox55 = New System.Windows.Forms.PictureBox()
        Me.pictureBox56 = New System.Windows.Forms.PictureBox()
        Me.pictureBox57 = New System.Windows.Forms.PictureBox()
        Me.pictureBox58 = New System.Windows.Forms.PictureBox()
        Me.pictureBox59 = New System.Windows.Forms.PictureBox()
        Me.pictureBox60 = New System.Windows.Forms.PictureBox()
        Me.pictureBox61 = New System.Windows.Forms.PictureBox()
        Me.pictureBox62 = New System.Windows.Forms.PictureBox()
        Me.pictureBox63 = New System.Windows.Forms.PictureBox()
        Me.pictureBox43 = New System.Windows.Forms.PictureBox()
        Me.pictureBox44 = New System.Windows.Forms.PictureBox()
        Me.pictureBox45 = New System.Windows.Forms.PictureBox()
        Me.pictureBox46 = New System.Windows.Forms.PictureBox()
        Me.pictureBox47 = New System.Windows.Forms.PictureBox()
        Me.pictureBox49 = New System.Windows.Forms.PictureBox()
        Me.pictureBox36 = New System.Windows.Forms.PictureBox()
        Me.pictureBox37 = New System.Windows.Forms.PictureBox()
        Me.pictureBox38 = New System.Windows.Forms.PictureBox()
        Me.pictureBox39 = New System.Windows.Forms.PictureBox()
        Me.pictureBox40 = New System.Windows.Forms.PictureBox()
        Me.pictureBox41 = New System.Windows.Forms.PictureBox()
        Me.pictureBox42 = New System.Windows.Forms.PictureBox()
        Me.pictureBox29 = New System.Windows.Forms.PictureBox()
        Me.pictureBox30 = New System.Windows.Forms.PictureBox()
        Me.pictureBox31 = New System.Windows.Forms.PictureBox()
        Me.pictureBox32 = New System.Windows.Forms.PictureBox()
        Me.pictureBox33 = New System.Windows.Forms.PictureBox()
        Me.pictureBox34 = New System.Windows.Forms.PictureBox()
        Me.pictureBox35 = New System.Windows.Forms.PictureBox()
        Me.label5 = New System.Windows.Forms.Label()
        Me.label1 = New System.Windows.Forms.Label()
        Me.Panel1 = New System.Windows.Forms.Panel()
        CType(Me.PictureBox100, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox99, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pictureBox92, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pictureBox93, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pictureBox94, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pictureBox95, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pictureBox96, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pictureBox97, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pictureBox98, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pictureBox22, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pictureBox23, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pictureBox24, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pictureBox25, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pictureBox26, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pictureBox27, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pictureBox28, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pictureBox64, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pictureBox65, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pictureBox66, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pictureBox67, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pictureBox68, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pictureBox69, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pictureBox70, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pictureBox71, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pictureBox72, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pictureBox73, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pictureBox74, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pictureBox75, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pictureBox76, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pictureBox77, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pictureBox78, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pictureBox79, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pictureBox80, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pictureBox81, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pictureBox82, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pictureBox83, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pictureBox84, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pictureBox85, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pictureBox86, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pictureBox87, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pictureBox88, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pictureBox89, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pictureBox90, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pictureBox91, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pictureBox3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pictureBox4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pictureBox5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pictureBox6, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pictureBox7, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pictureBox8, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pictureBox9, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pictureBox10, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pictureBox11, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pictureBox12, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pictureBox13, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pictureBox14, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pictureBox15, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pictureBox16, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pictureBox17, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pictureBox18, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pictureBox19, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pictureBox20, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pictureBox21, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pictureBox48, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pictureBox50, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pictureBox51, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pictureBox52, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pictureBox53, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pictureBox54, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pictureBox55, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pictureBox56, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pictureBox57, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pictureBox58, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pictureBox59, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pictureBox60, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pictureBox61, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pictureBox62, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pictureBox63, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pictureBox43, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pictureBox44, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pictureBox45, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pictureBox46, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pictureBox47, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pictureBox49, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pictureBox36, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pictureBox37, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pictureBox38, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pictureBox39, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pictureBox40, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pictureBox41, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pictureBox42, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pictureBox29, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pictureBox30, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pictureBox31, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pictureBox32, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pictureBox33, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pictureBox34, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pictureBox35, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'PictureBox100
        '
        Me.PictureBox100.Location = New System.Drawing.Point(400, 75)
        Me.PictureBox100.Name = "PictureBox100"
        Me.PictureBox100.Size = New System.Drawing.Size(38, 32)
        Me.PictureBox100.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox100.TabIndex = 615
        Me.PictureBox100.TabStop = False
        '
        'PictureBox99
        '
        Me.PictureBox99.Location = New System.Drawing.Point(346, 75)
        Me.PictureBox99.Name = "PictureBox99"
        Me.PictureBox99.Size = New System.Drawing.Size(38, 32)
        Me.PictureBox99.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox99.TabIndex = 614
        Me.PictureBox99.TabStop = False
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(449, 82)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(65, 17)
        Me.Label3.TabIndex = 613
        Me.Label3.Text = "Available"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(281, 82)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(56, 17)
        Me.Label2.TabIndex = 612
        Me.Label2.Text = "Booked"
        '
        'button4
        '
        Me.button4.BackColor = System.Drawing.SystemColors.AppWorkspace
        Me.button4.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.button4.Location = New System.Drawing.Point(587, 543)
        Me.button4.Name = "button4"
        Me.button4.Size = New System.Drawing.Size(102, 35)
        Me.button4.TabIndex = 610
        Me.button4.Text = "SAVE"
        Me.button4.UseVisualStyleBackColor = False
        '
        'pictureBox92
        '
        Me.pictureBox92.Location = New System.Drawing.Point(311, 409)
        Me.pictureBox92.Name = "pictureBox92"
        Me.pictureBox92.Size = New System.Drawing.Size(38, 32)
        Me.pictureBox92.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pictureBox92.TabIndex = 609
        Me.pictureBox92.TabStop = False
        '
        'pictureBox93
        '
        Me.pictureBox93.Location = New System.Drawing.Point(267, 409)
        Me.pictureBox93.Name = "pictureBox93"
        Me.pictureBox93.Size = New System.Drawing.Size(38, 32)
        Me.pictureBox93.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pictureBox93.TabIndex = 608
        Me.pictureBox93.TabStop = False
        '
        'pictureBox94
        '
        Me.pictureBox94.Location = New System.Drawing.Point(223, 409)
        Me.pictureBox94.Name = "pictureBox94"
        Me.pictureBox94.Size = New System.Drawing.Size(38, 32)
        Me.pictureBox94.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pictureBox94.TabIndex = 607
        Me.pictureBox94.TabStop = False
        '
        'pictureBox95
        '
        Me.pictureBox95.Location = New System.Drawing.Point(179, 409)
        Me.pictureBox95.Name = "pictureBox95"
        Me.pictureBox95.Size = New System.Drawing.Size(38, 32)
        Me.pictureBox95.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pictureBox95.TabIndex = 606
        Me.pictureBox95.TabStop = False
        '
        'pictureBox96
        '
        Me.pictureBox96.Location = New System.Drawing.Point(135, 409)
        Me.pictureBox96.Name = "pictureBox96"
        Me.pictureBox96.Size = New System.Drawing.Size(38, 32)
        Me.pictureBox96.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pictureBox96.TabIndex = 605
        Me.pictureBox96.TabStop = False
        '
        'pictureBox97
        '
        Me.pictureBox97.Location = New System.Drawing.Point(91, 409)
        Me.pictureBox97.Name = "pictureBox97"
        Me.pictureBox97.Size = New System.Drawing.Size(38, 32)
        Me.pictureBox97.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pictureBox97.TabIndex = 604
        Me.pictureBox97.TabStop = False
        '
        'pictureBox98
        '
        Me.pictureBox98.Location = New System.Drawing.Point(47, 409)
        Me.pictureBox98.Name = "pictureBox98"
        Me.pictureBox98.Size = New System.Drawing.Size(38, 32)
        Me.pictureBox98.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pictureBox98.TabIndex = 603
        Me.pictureBox98.TabStop = False
        '
        'pictureBox22
        '
        Me.pictureBox22.InitialImage = CType(resources.GetObject("pictureBox22.InitialImage"), System.Drawing.Image)
        Me.pictureBox22.Location = New System.Drawing.Point(465, 333)
        Me.pictureBox22.Name = "pictureBox22"
        Me.pictureBox22.Size = New System.Drawing.Size(38, 32)
        Me.pictureBox22.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pictureBox22.TabIndex = 602
        Me.pictureBox22.TabStop = False
        '
        'pictureBox23
        '
        Me.pictureBox23.Location = New System.Drawing.Point(685, 333)
        Me.pictureBox23.Name = "pictureBox23"
        Me.pictureBox23.Size = New System.Drawing.Size(38, 32)
        Me.pictureBox23.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pictureBox23.TabIndex = 601
        Me.pictureBox23.TabStop = False
        '
        'pictureBox24
        '
        Me.pictureBox24.Location = New System.Drawing.Point(641, 333)
        Me.pictureBox24.Name = "pictureBox24"
        Me.pictureBox24.Size = New System.Drawing.Size(38, 32)
        Me.pictureBox24.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pictureBox24.TabIndex = 600
        Me.pictureBox24.TabStop = False
        '
        'pictureBox25
        '
        Me.pictureBox25.Location = New System.Drawing.Point(597, 333)
        Me.pictureBox25.Name = "pictureBox25"
        Me.pictureBox25.Size = New System.Drawing.Size(38, 32)
        Me.pictureBox25.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pictureBox25.TabIndex = 599
        Me.pictureBox25.TabStop = False
        '
        'pictureBox26
        '
        Me.pictureBox26.Location = New System.Drawing.Point(553, 333)
        Me.pictureBox26.Name = "pictureBox26"
        Me.pictureBox26.Size = New System.Drawing.Size(38, 32)
        Me.pictureBox26.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pictureBox26.TabIndex = 598
        Me.pictureBox26.TabStop = False
        '
        'pictureBox27
        '
        Me.pictureBox27.Location = New System.Drawing.Point(509, 333)
        Me.pictureBox27.Name = "pictureBox27"
        Me.pictureBox27.Size = New System.Drawing.Size(38, 32)
        Me.pictureBox27.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pictureBox27.TabIndex = 597
        Me.pictureBox27.TabStop = False
        '
        'pictureBox28
        '
        Me.pictureBox28.InitialImage = CType(resources.GetObject("pictureBox28.InitialImage"), System.Drawing.Image)
        Me.pictureBox28.Location = New System.Drawing.Point(421, 333)
        Me.pictureBox28.Name = "pictureBox28"
        Me.pictureBox28.Size = New System.Drawing.Size(38, 32)
        Me.pictureBox28.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pictureBox28.TabIndex = 596
        Me.pictureBox28.TabStop = False
        '
        'pictureBox64
        '
        Me.pictureBox64.Location = New System.Drawing.Point(685, 371)
        Me.pictureBox64.Name = "pictureBox64"
        Me.pictureBox64.Size = New System.Drawing.Size(38, 32)
        Me.pictureBox64.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pictureBox64.TabIndex = 595
        Me.pictureBox64.TabStop = False
        '
        'pictureBox65
        '
        Me.pictureBox65.Location = New System.Drawing.Point(641, 371)
        Me.pictureBox65.Name = "pictureBox65"
        Me.pictureBox65.Size = New System.Drawing.Size(38, 32)
        Me.pictureBox65.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pictureBox65.TabIndex = 594
        Me.pictureBox65.TabStop = False
        '
        'pictureBox66
        '
        Me.pictureBox66.Location = New System.Drawing.Point(597, 371)
        Me.pictureBox66.Name = "pictureBox66"
        Me.pictureBox66.Size = New System.Drawing.Size(38, 32)
        Me.pictureBox66.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pictureBox66.TabIndex = 593
        Me.pictureBox66.TabStop = False
        '
        'pictureBox67
        '
        Me.pictureBox67.Location = New System.Drawing.Point(553, 371)
        Me.pictureBox67.Name = "pictureBox67"
        Me.pictureBox67.Size = New System.Drawing.Size(38, 32)
        Me.pictureBox67.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pictureBox67.TabIndex = 592
        Me.pictureBox67.TabStop = False
        '
        'pictureBox68
        '
        Me.pictureBox68.Location = New System.Drawing.Point(509, 371)
        Me.pictureBox68.Name = "pictureBox68"
        Me.pictureBox68.Size = New System.Drawing.Size(38, 32)
        Me.pictureBox68.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pictureBox68.TabIndex = 591
        Me.pictureBox68.TabStop = False
        '
        'pictureBox69
        '
        Me.pictureBox69.Location = New System.Drawing.Point(465, 371)
        Me.pictureBox69.Name = "pictureBox69"
        Me.pictureBox69.Size = New System.Drawing.Size(38, 32)
        Me.pictureBox69.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pictureBox69.TabIndex = 590
        Me.pictureBox69.TabStop = False
        '
        'pictureBox70
        '
        Me.pictureBox70.Location = New System.Drawing.Point(421, 371)
        Me.pictureBox70.Name = "pictureBox70"
        Me.pictureBox70.Size = New System.Drawing.Size(38, 32)
        Me.pictureBox70.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pictureBox70.TabIndex = 589
        Me.pictureBox70.TabStop = False
        '
        'pictureBox71
        '
        Me.pictureBox71.Location = New System.Drawing.Point(685, 409)
        Me.pictureBox71.Name = "pictureBox71"
        Me.pictureBox71.Size = New System.Drawing.Size(38, 32)
        Me.pictureBox71.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pictureBox71.TabIndex = 588
        Me.pictureBox71.TabStop = False
        '
        'pictureBox72
        '
        Me.pictureBox72.Location = New System.Drawing.Point(641, 409)
        Me.pictureBox72.Name = "pictureBox72"
        Me.pictureBox72.Size = New System.Drawing.Size(38, 32)
        Me.pictureBox72.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pictureBox72.TabIndex = 587
        Me.pictureBox72.TabStop = False
        '
        'pictureBox73
        '
        Me.pictureBox73.Location = New System.Drawing.Point(597, 409)
        Me.pictureBox73.Name = "pictureBox73"
        Me.pictureBox73.Size = New System.Drawing.Size(38, 32)
        Me.pictureBox73.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pictureBox73.TabIndex = 586
        Me.pictureBox73.TabStop = False
        '
        'pictureBox74
        '
        Me.pictureBox74.Location = New System.Drawing.Point(553, 409)
        Me.pictureBox74.Name = "pictureBox74"
        Me.pictureBox74.Size = New System.Drawing.Size(38, 32)
        Me.pictureBox74.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pictureBox74.TabIndex = 585
        Me.pictureBox74.TabStop = False
        '
        'pictureBox75
        '
        Me.pictureBox75.Location = New System.Drawing.Point(509, 409)
        Me.pictureBox75.Name = "pictureBox75"
        Me.pictureBox75.Size = New System.Drawing.Size(38, 32)
        Me.pictureBox75.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pictureBox75.TabIndex = 584
        Me.pictureBox75.TabStop = False
        '
        'pictureBox76
        '
        Me.pictureBox76.Location = New System.Drawing.Point(465, 409)
        Me.pictureBox76.Name = "pictureBox76"
        Me.pictureBox76.Size = New System.Drawing.Size(38, 32)
        Me.pictureBox76.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pictureBox76.TabIndex = 583
        Me.pictureBox76.TabStop = False
        '
        'pictureBox77
        '
        Me.pictureBox77.Location = New System.Drawing.Point(421, 409)
        Me.pictureBox77.Name = "pictureBox77"
        Me.pictureBox77.Size = New System.Drawing.Size(38, 32)
        Me.pictureBox77.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pictureBox77.TabIndex = 582
        Me.pictureBox77.TabStop = False
        '
        'pictureBox78
        '
        Me.pictureBox78.Location = New System.Drawing.Point(685, 257)
        Me.pictureBox78.Name = "pictureBox78"
        Me.pictureBox78.Size = New System.Drawing.Size(38, 32)
        Me.pictureBox78.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pictureBox78.TabIndex = 581
        Me.pictureBox78.TabStop = False
        '
        'pictureBox79
        '
        Me.pictureBox79.Location = New System.Drawing.Point(641, 257)
        Me.pictureBox79.Name = "pictureBox79"
        Me.pictureBox79.Size = New System.Drawing.Size(38, 32)
        Me.pictureBox79.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pictureBox79.TabIndex = 580
        Me.pictureBox79.TabStop = False
        '
        'pictureBox80
        '
        Me.pictureBox80.Location = New System.Drawing.Point(597, 257)
        Me.pictureBox80.Name = "pictureBox80"
        Me.pictureBox80.Size = New System.Drawing.Size(38, 32)
        Me.pictureBox80.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pictureBox80.TabIndex = 579
        Me.pictureBox80.TabStop = False
        '
        'pictureBox81
        '
        Me.pictureBox81.Location = New System.Drawing.Point(553, 257)
        Me.pictureBox81.Name = "pictureBox81"
        Me.pictureBox81.Size = New System.Drawing.Size(38, 32)
        Me.pictureBox81.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pictureBox81.TabIndex = 578
        Me.pictureBox81.TabStop = False
        '
        'pictureBox82
        '
        Me.pictureBox82.Location = New System.Drawing.Point(509, 257)
        Me.pictureBox82.Name = "pictureBox82"
        Me.pictureBox82.Size = New System.Drawing.Size(38, 32)
        Me.pictureBox82.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pictureBox82.TabIndex = 577
        Me.pictureBox82.TabStop = False
        '
        'pictureBox83
        '
        Me.pictureBox83.Location = New System.Drawing.Point(465, 257)
        Me.pictureBox83.Name = "pictureBox83"
        Me.pictureBox83.Size = New System.Drawing.Size(38, 32)
        Me.pictureBox83.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pictureBox83.TabIndex = 576
        Me.pictureBox83.TabStop = False
        '
        'pictureBox84
        '
        Me.pictureBox84.Location = New System.Drawing.Point(421, 257)
        Me.pictureBox84.Name = "pictureBox84"
        Me.pictureBox84.Size = New System.Drawing.Size(38, 32)
        Me.pictureBox84.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pictureBox84.TabIndex = 575
        Me.pictureBox84.TabStop = False
        '
        'pictureBox85
        '
        Me.pictureBox85.Location = New System.Drawing.Point(685, 295)
        Me.pictureBox85.Name = "pictureBox85"
        Me.pictureBox85.Size = New System.Drawing.Size(38, 32)
        Me.pictureBox85.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pictureBox85.TabIndex = 574
        Me.pictureBox85.TabStop = False
        '
        'pictureBox86
        '
        Me.pictureBox86.Location = New System.Drawing.Point(641, 295)
        Me.pictureBox86.Name = "pictureBox86"
        Me.pictureBox86.Size = New System.Drawing.Size(38, 32)
        Me.pictureBox86.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pictureBox86.TabIndex = 573
        Me.pictureBox86.TabStop = False
        '
        'pictureBox87
        '
        Me.pictureBox87.Location = New System.Drawing.Point(597, 295)
        Me.pictureBox87.Name = "pictureBox87"
        Me.pictureBox87.Size = New System.Drawing.Size(38, 32)
        Me.pictureBox87.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pictureBox87.TabIndex = 572
        Me.pictureBox87.TabStop = False
        '
        'pictureBox88
        '
        Me.pictureBox88.Location = New System.Drawing.Point(553, 295)
        Me.pictureBox88.Name = "pictureBox88"
        Me.pictureBox88.Size = New System.Drawing.Size(38, 32)
        Me.pictureBox88.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pictureBox88.TabIndex = 571
        Me.pictureBox88.TabStop = False
        '
        'pictureBox89
        '
        Me.pictureBox89.Location = New System.Drawing.Point(509, 295)
        Me.pictureBox89.Name = "pictureBox89"
        Me.pictureBox89.Size = New System.Drawing.Size(38, 32)
        Me.pictureBox89.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pictureBox89.TabIndex = 570
        Me.pictureBox89.TabStop = False
        '
        'pictureBox90
        '
        Me.pictureBox90.Location = New System.Drawing.Point(465, 295)
        Me.pictureBox90.Name = "pictureBox90"
        Me.pictureBox90.Size = New System.Drawing.Size(38, 32)
        Me.pictureBox90.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pictureBox90.TabIndex = 569
        Me.pictureBox90.TabStop = False
        '
        'pictureBox91
        '
        Me.pictureBox91.Location = New System.Drawing.Point(421, 295)
        Me.pictureBox91.Name = "pictureBox91"
        Me.pictureBox91.Size = New System.Drawing.Size(38, 32)
        Me.pictureBox91.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pictureBox91.TabIndex = 568
        Me.pictureBox91.TabStop = False
        '
        'pictureBox1
        '
        Me.pictureBox1.InitialImage = CType(resources.GetObject("pictureBox1.InitialImage"), System.Drawing.Image)
        Me.pictureBox1.Location = New System.Drawing.Point(91, 295)
        Me.pictureBox1.Name = "pictureBox1"
        Me.pictureBox1.Size = New System.Drawing.Size(38, 32)
        Me.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pictureBox1.TabIndex = 567
        Me.pictureBox1.TabStop = False
        '
        'pictureBox2
        '
        Me.pictureBox2.Location = New System.Drawing.Point(311, 295)
        Me.pictureBox2.Name = "pictureBox2"
        Me.pictureBox2.Size = New System.Drawing.Size(38, 32)
        Me.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pictureBox2.TabIndex = 566
        Me.pictureBox2.TabStop = False
        '
        'pictureBox3
        '
        Me.pictureBox3.Location = New System.Drawing.Point(267, 295)
        Me.pictureBox3.Name = "pictureBox3"
        Me.pictureBox3.Size = New System.Drawing.Size(38, 32)
        Me.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pictureBox3.TabIndex = 565
        Me.pictureBox3.TabStop = False
        '
        'pictureBox4
        '
        Me.pictureBox4.Location = New System.Drawing.Point(223, 295)
        Me.pictureBox4.Name = "pictureBox4"
        Me.pictureBox4.Size = New System.Drawing.Size(38, 32)
        Me.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pictureBox4.TabIndex = 564
        Me.pictureBox4.TabStop = False
        '
        'pictureBox5
        '
        Me.pictureBox5.Location = New System.Drawing.Point(179, 295)
        Me.pictureBox5.Name = "pictureBox5"
        Me.pictureBox5.Size = New System.Drawing.Size(38, 32)
        Me.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pictureBox5.TabIndex = 563
        Me.pictureBox5.TabStop = False
        '
        'pictureBox6
        '
        Me.pictureBox6.Location = New System.Drawing.Point(135, 295)
        Me.pictureBox6.Name = "pictureBox6"
        Me.pictureBox6.Size = New System.Drawing.Size(38, 32)
        Me.pictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pictureBox6.TabIndex = 562
        Me.pictureBox6.TabStop = False
        '
        'pictureBox7
        '
        Me.pictureBox7.InitialImage = CType(resources.GetObject("pictureBox7.InitialImage"), System.Drawing.Image)
        Me.pictureBox7.Location = New System.Drawing.Point(47, 295)
        Me.pictureBox7.Name = "pictureBox7"
        Me.pictureBox7.Size = New System.Drawing.Size(38, 32)
        Me.pictureBox7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pictureBox7.TabIndex = 561
        Me.pictureBox7.TabStop = False
        '
        'pictureBox8
        '
        Me.pictureBox8.Location = New System.Drawing.Point(311, 333)
        Me.pictureBox8.Name = "pictureBox8"
        Me.pictureBox8.Size = New System.Drawing.Size(38, 32)
        Me.pictureBox8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pictureBox8.TabIndex = 560
        Me.pictureBox8.TabStop = False
        '
        'pictureBox9
        '
        Me.pictureBox9.Location = New System.Drawing.Point(267, 333)
        Me.pictureBox9.Name = "pictureBox9"
        Me.pictureBox9.Size = New System.Drawing.Size(38, 32)
        Me.pictureBox9.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pictureBox9.TabIndex = 559
        Me.pictureBox9.TabStop = False
        '
        'pictureBox10
        '
        Me.pictureBox10.Location = New System.Drawing.Point(223, 333)
        Me.pictureBox10.Name = "pictureBox10"
        Me.pictureBox10.Size = New System.Drawing.Size(38, 32)
        Me.pictureBox10.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pictureBox10.TabIndex = 558
        Me.pictureBox10.TabStop = False
        '
        'pictureBox11
        '
        Me.pictureBox11.Location = New System.Drawing.Point(179, 333)
        Me.pictureBox11.Name = "pictureBox11"
        Me.pictureBox11.Size = New System.Drawing.Size(38, 32)
        Me.pictureBox11.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pictureBox11.TabIndex = 557
        Me.pictureBox11.TabStop = False
        '
        'pictureBox12
        '
        Me.pictureBox12.Location = New System.Drawing.Point(135, 333)
        Me.pictureBox12.Name = "pictureBox12"
        Me.pictureBox12.Size = New System.Drawing.Size(38, 32)
        Me.pictureBox12.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pictureBox12.TabIndex = 556
        Me.pictureBox12.TabStop = False
        '
        'pictureBox13
        '
        Me.pictureBox13.Location = New System.Drawing.Point(91, 333)
        Me.pictureBox13.Name = "pictureBox13"
        Me.pictureBox13.Size = New System.Drawing.Size(38, 32)
        Me.pictureBox13.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pictureBox13.TabIndex = 555
        Me.pictureBox13.TabStop = False
        '
        'pictureBox14
        '
        Me.pictureBox14.Location = New System.Drawing.Point(47, 333)
        Me.pictureBox14.Name = "pictureBox14"
        Me.pictureBox14.Size = New System.Drawing.Size(38, 32)
        Me.pictureBox14.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pictureBox14.TabIndex = 554
        Me.pictureBox14.TabStop = False
        '
        'pictureBox15
        '
        Me.pictureBox15.Location = New System.Drawing.Point(311, 371)
        Me.pictureBox15.Name = "pictureBox15"
        Me.pictureBox15.Size = New System.Drawing.Size(38, 32)
        Me.pictureBox15.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pictureBox15.TabIndex = 553
        Me.pictureBox15.TabStop = False
        '
        'pictureBox16
        '
        Me.pictureBox16.Location = New System.Drawing.Point(267, 371)
        Me.pictureBox16.Name = "pictureBox16"
        Me.pictureBox16.Size = New System.Drawing.Size(38, 32)
        Me.pictureBox16.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pictureBox16.TabIndex = 552
        Me.pictureBox16.TabStop = False
        '
        'pictureBox17
        '
        Me.pictureBox17.Location = New System.Drawing.Point(223, 371)
        Me.pictureBox17.Name = "pictureBox17"
        Me.pictureBox17.Size = New System.Drawing.Size(38, 32)
        Me.pictureBox17.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pictureBox17.TabIndex = 551
        Me.pictureBox17.TabStop = False
        '
        'pictureBox18
        '
        Me.pictureBox18.Location = New System.Drawing.Point(179, 371)
        Me.pictureBox18.Name = "pictureBox18"
        Me.pictureBox18.Size = New System.Drawing.Size(38, 32)
        Me.pictureBox18.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pictureBox18.TabIndex = 550
        Me.pictureBox18.TabStop = False
        '
        'pictureBox19
        '
        Me.pictureBox19.Location = New System.Drawing.Point(135, 371)
        Me.pictureBox19.Name = "pictureBox19"
        Me.pictureBox19.Size = New System.Drawing.Size(38, 32)
        Me.pictureBox19.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pictureBox19.TabIndex = 549
        Me.pictureBox19.TabStop = False
        '
        'pictureBox20
        '
        Me.pictureBox20.Location = New System.Drawing.Point(91, 371)
        Me.pictureBox20.Name = "pictureBox20"
        Me.pictureBox20.Size = New System.Drawing.Size(38, 32)
        Me.pictureBox20.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pictureBox20.TabIndex = 548
        Me.pictureBox20.TabStop = False
        '
        'pictureBox21
        '
        Me.pictureBox21.Location = New System.Drawing.Point(47, 371)
        Me.pictureBox21.Name = "pictureBox21"
        Me.pictureBox21.Size = New System.Drawing.Size(38, 32)
        Me.pictureBox21.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pictureBox21.TabIndex = 547
        Me.pictureBox21.TabStop = False
        '
        'pictureBox48
        '
        Me.pictureBox48.InitialImage = CType(resources.GetObject("pictureBox48.InitialImage"), System.Drawing.Image)
        Me.pictureBox48.Location = New System.Drawing.Point(91, 181)
        Me.pictureBox48.Name = "pictureBox48"
        Me.pictureBox48.Size = New System.Drawing.Size(38, 32)
        Me.pictureBox48.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pictureBox48.TabIndex = 546
        Me.pictureBox48.TabStop = False
        '
        'button3
        '
        Me.button3.BackColor = System.Drawing.SystemColors.AppWorkspace
        Me.button3.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.button3.Location = New System.Drawing.Point(434, 543)
        Me.button3.Name = "button3"
        Me.button3.Size = New System.Drawing.Size(103, 35)
        Me.button3.TabIndex = 545
        Me.button3.Text = "DELETE"
        Me.button3.UseVisualStyleBackColor = False
        '
        'button2
        '
        Me.button2.BackColor = System.Drawing.SystemColors.AppWorkspace
        Me.button2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.button2.Location = New System.Drawing.Point(281, 543)
        Me.button2.Name = "button2"
        Me.button2.Size = New System.Drawing.Size(103, 35)
        Me.button2.TabIndex = 544
        Me.button2.Text = "EDIT"
        Me.button2.UseVisualStyleBackColor = False
        '
        'label34
        '
        Me.label34.AutoSize = True
        Me.label34.BackColor = System.Drawing.SystemColors.AppWorkspace
        Me.label34.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.label34.Location = New System.Drawing.Point(316, 486)
        Me.label34.Name = "label34"
        Me.label34.Size = New System.Drawing.Size(139, 25)
        Me.label34.TabIndex = 543
        Me.label34.Text = "cinema screen"
        '
        'button1
        '
        Me.button1.BackColor = System.Drawing.SystemColors.AppWorkspace
        Me.button1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.button1.Location = New System.Drawing.Point(114, 543)
        Me.button1.Name = "button1"
        Me.button1.Size = New System.Drawing.Size(103, 35)
        Me.button1.TabIndex = 542
        Me.button1.Text = "ADD"
        Me.button1.UseVisualStyleBackColor = False
        '
        'label27
        '
        Me.label27.AutoSize = True
        Me.label27.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.label27.Location = New System.Drawing.Point(21, 185)
        Me.label27.Name = "label27"
        Me.label27.Size = New System.Drawing.Size(22, 20)
        Me.label27.TabIndex = 541
        Me.label27.Text = "G"
        '
        'label28
        '
        Me.label28.AutoSize = True
        Me.label28.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.label28.Location = New System.Drawing.Point(22, 224)
        Me.label28.Name = "label28"
        Me.label28.Size = New System.Drawing.Size(19, 20)
        Me.label28.TabIndex = 540
        Me.label28.Text = "F"
        '
        'label29
        '
        Me.label29.AutoSize = True
        Me.label29.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.label29.Location = New System.Drawing.Point(21, 261)
        Me.label29.Name = "label29"
        Me.label29.Size = New System.Drawing.Size(20, 20)
        Me.label29.TabIndex = 539
        Me.label29.Text = "E"
        '
        'label30
        '
        Me.label30.AutoSize = True
        Me.label30.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.label30.Location = New System.Drawing.Point(21, 301)
        Me.label30.Name = "label30"
        Me.label30.Size = New System.Drawing.Size(22, 20)
        Me.label30.TabIndex = 538
        Me.label30.Text = "D"
        '
        'label31
        '
        Me.label31.AutoSize = True
        Me.label31.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.label31.Location = New System.Drawing.Point(21, 337)
        Me.label31.Name = "label31"
        Me.label31.Size = New System.Drawing.Size(21, 20)
        Me.label31.TabIndex = 537
        Me.label31.Text = "C"
        '
        'label32
        '
        Me.label32.AutoSize = True
        Me.label32.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.label32.Location = New System.Drawing.Point(22, 375)
        Me.label32.Name = "label32"
        Me.label32.Size = New System.Drawing.Size(21, 20)
        Me.label32.TabIndex = 536
        Me.label32.Text = "B"
        '
        'label33
        '
        Me.label33.AutoSize = True
        Me.label33.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.label33.Location = New System.Drawing.Point(22, 414)
        Me.label33.Name = "label33"
        Me.label33.Size = New System.Drawing.Size(20, 20)
        Me.label33.TabIndex = 535
        Me.label33.Text = "A"
        '
        'label26
        '
        Me.label26.AutoSize = True
        Me.label26.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.label26.Location = New System.Drawing.Point(396, 185)
        Me.label26.Name = "label26"
        Me.label26.Size = New System.Drawing.Size(22, 20)
        Me.label26.TabIndex = 534
        Me.label26.Text = "G"
        '
        'label25
        '
        Me.label25.AutoSize = True
        Me.label25.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.label25.Location = New System.Drawing.Point(397, 224)
        Me.label25.Name = "label25"
        Me.label25.Size = New System.Drawing.Size(19, 20)
        Me.label25.TabIndex = 533
        Me.label25.Text = "F"
        '
        'label24
        '
        Me.label24.AutoSize = True
        Me.label24.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.label24.Location = New System.Drawing.Point(396, 261)
        Me.label24.Name = "label24"
        Me.label24.Size = New System.Drawing.Size(20, 20)
        Me.label24.TabIndex = 532
        Me.label24.Text = "E"
        '
        'label23
        '
        Me.label23.AutoSize = True
        Me.label23.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.label23.Location = New System.Drawing.Point(396, 301)
        Me.label23.Name = "label23"
        Me.label23.Size = New System.Drawing.Size(22, 20)
        Me.label23.TabIndex = 531
        Me.label23.Text = "D"
        '
        'label22
        '
        Me.label22.AutoSize = True
        Me.label22.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.label22.Location = New System.Drawing.Point(396, 337)
        Me.label22.Name = "label22"
        Me.label22.Size = New System.Drawing.Size(21, 20)
        Me.label22.TabIndex = 530
        Me.label22.Text = "C"
        '
        'label21
        '
        Me.label21.AutoSize = True
        Me.label21.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.label21.Location = New System.Drawing.Point(397, 375)
        Me.label21.Name = "label21"
        Me.label21.Size = New System.Drawing.Size(21, 20)
        Me.label21.TabIndex = 529
        Me.label21.Text = "B"
        '
        'label20
        '
        Me.label20.AutoSize = True
        Me.label20.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.label20.Location = New System.Drawing.Point(397, 414)
        Me.label20.Name = "label20"
        Me.label20.Size = New System.Drawing.Size(20, 20)
        Me.label20.TabIndex = 528
        Me.label20.Text = "A"
        '
        'label13
        '
        Me.label13.AutoSize = True
        Me.label13.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.label13.Location = New System.Drawing.Point(695, 158)
        Me.label13.Name = "label13"
        Me.label13.Size = New System.Drawing.Size(27, 20)
        Me.label13.TabIndex = 527
        Me.label13.Text = "14"
        '
        'label14
        '
        Me.label14.AutoSize = True
        Me.label14.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.label14.Location = New System.Drawing.Point(651, 158)
        Me.label14.Name = "label14"
        Me.label14.Size = New System.Drawing.Size(27, 20)
        Me.label14.TabIndex = 526
        Me.label14.Text = "13"
        '
        'label15
        '
        Me.label15.AutoSize = True
        Me.label15.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.label15.Location = New System.Drawing.Point(606, 158)
        Me.label15.Name = "label15"
        Me.label15.Size = New System.Drawing.Size(27, 20)
        Me.label15.TabIndex = 525
        Me.label15.Text = "12"
        '
        'label16
        '
        Me.label16.AutoSize = True
        Me.label16.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.label16.Location = New System.Drawing.Point(564, 158)
        Me.label16.Name = "label16"
        Me.label16.Size = New System.Drawing.Size(27, 20)
        Me.label16.TabIndex = 524
        Me.label16.Text = "11"
        '
        'label17
        '
        Me.label17.AutoSize = True
        Me.label17.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.label17.Location = New System.Drawing.Point(520, 158)
        Me.label17.Name = "label17"
        Me.label17.Size = New System.Drawing.Size(27, 20)
        Me.label17.TabIndex = 523
        Me.label17.Text = "10"
        '
        'label18
        '
        Me.label18.AutoSize = True
        Me.label18.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.label18.Location = New System.Drawing.Point(474, 158)
        Me.label18.Name = "label18"
        Me.label18.Size = New System.Drawing.Size(18, 20)
        Me.label18.TabIndex = 522
        Me.label18.Text = "9"
        '
        'label19
        '
        Me.label19.AutoSize = True
        Me.label19.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.label19.Location = New System.Drawing.Point(430, 158)
        Me.label19.Name = "label19"
        Me.label19.Size = New System.Drawing.Size(18, 20)
        Me.label19.TabIndex = 521
        Me.label19.Text = "8"
        '
        'label12
        '
        Me.label12.AutoSize = True
        Me.label12.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.label12.Location = New System.Drawing.Point(321, 158)
        Me.label12.Name = "label12"
        Me.label12.Size = New System.Drawing.Size(18, 20)
        Me.label12.TabIndex = 520
        Me.label12.Text = "7"
        '
        'label11
        '
        Me.label11.AutoSize = True
        Me.label11.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.label11.Location = New System.Drawing.Point(277, 158)
        Me.label11.Name = "label11"
        Me.label11.Size = New System.Drawing.Size(18, 20)
        Me.label11.TabIndex = 519
        Me.label11.Text = "6"
        '
        'label10
        '
        Me.label10.AutoSize = True
        Me.label10.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.label10.Location = New System.Drawing.Point(232, 158)
        Me.label10.Name = "label10"
        Me.label10.Size = New System.Drawing.Size(18, 20)
        Me.label10.TabIndex = 518
        Me.label10.Text = "5"
        '
        'label9
        '
        Me.label9.AutoSize = True
        Me.label9.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.label9.Location = New System.Drawing.Point(190, 158)
        Me.label9.Name = "label9"
        Me.label9.Size = New System.Drawing.Size(18, 20)
        Me.label9.TabIndex = 517
        Me.label9.Text = "4"
        '
        'label8
        '
        Me.label8.AutoSize = True
        Me.label8.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.label8.Location = New System.Drawing.Point(146, 158)
        Me.label8.Name = "label8"
        Me.label8.Size = New System.Drawing.Size(18, 20)
        Me.label8.TabIndex = 516
        Me.label8.Text = "3"
        '
        'label7
        '
        Me.label7.AutoSize = True
        Me.label7.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.label7.Location = New System.Drawing.Point(100, 158)
        Me.label7.Name = "label7"
        Me.label7.Size = New System.Drawing.Size(18, 20)
        Me.label7.TabIndex = 515
        Me.label7.Text = "2"
        '
        'label6
        '
        Me.label6.AutoSize = True
        Me.label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.label6.Location = New System.Drawing.Point(56, 158)
        Me.label6.Name = "label6"
        Me.label6.Size = New System.Drawing.Size(18, 20)
        Me.label6.TabIndex = 514
        Me.label6.Text = "1"
        '
        'pictureBox50
        '
        Me.pictureBox50.Location = New System.Drawing.Point(685, 181)
        Me.pictureBox50.Name = "pictureBox50"
        Me.pictureBox50.Size = New System.Drawing.Size(38, 32)
        Me.pictureBox50.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pictureBox50.TabIndex = 513
        Me.pictureBox50.TabStop = False
        '
        'pictureBox51
        '
        Me.pictureBox51.Location = New System.Drawing.Point(641, 181)
        Me.pictureBox51.Name = "pictureBox51"
        Me.pictureBox51.Size = New System.Drawing.Size(38, 32)
        Me.pictureBox51.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pictureBox51.TabIndex = 512
        Me.pictureBox51.TabStop = False
        '
        'pictureBox52
        '
        Me.pictureBox52.Location = New System.Drawing.Point(597, 181)
        Me.pictureBox52.Name = "pictureBox52"
        Me.pictureBox52.Size = New System.Drawing.Size(38, 32)
        Me.pictureBox52.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pictureBox52.TabIndex = 511
        Me.pictureBox52.TabStop = False
        '
        'pictureBox53
        '
        Me.pictureBox53.Location = New System.Drawing.Point(553, 181)
        Me.pictureBox53.Name = "pictureBox53"
        Me.pictureBox53.Size = New System.Drawing.Size(38, 32)
        Me.pictureBox53.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pictureBox53.TabIndex = 510
        Me.pictureBox53.TabStop = False
        '
        'pictureBox54
        '
        Me.pictureBox54.Location = New System.Drawing.Point(509, 181)
        Me.pictureBox54.Name = "pictureBox54"
        Me.pictureBox54.Size = New System.Drawing.Size(38, 32)
        Me.pictureBox54.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pictureBox54.TabIndex = 509
        Me.pictureBox54.TabStop = False
        '
        'pictureBox55
        '
        Me.pictureBox55.Location = New System.Drawing.Point(465, 181)
        Me.pictureBox55.Name = "pictureBox55"
        Me.pictureBox55.Size = New System.Drawing.Size(38, 32)
        Me.pictureBox55.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pictureBox55.TabIndex = 508
        Me.pictureBox55.TabStop = False
        '
        'pictureBox56
        '
        Me.pictureBox56.Location = New System.Drawing.Point(421, 181)
        Me.pictureBox56.Name = "pictureBox56"
        Me.pictureBox56.Size = New System.Drawing.Size(38, 32)
        Me.pictureBox56.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pictureBox56.TabIndex = 507
        Me.pictureBox56.TabStop = False
        '
        'pictureBox57
        '
        Me.pictureBox57.Location = New System.Drawing.Point(685, 219)
        Me.pictureBox57.Name = "pictureBox57"
        Me.pictureBox57.Size = New System.Drawing.Size(38, 32)
        Me.pictureBox57.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pictureBox57.TabIndex = 506
        Me.pictureBox57.TabStop = False
        '
        'pictureBox58
        '
        Me.pictureBox58.Location = New System.Drawing.Point(641, 219)
        Me.pictureBox58.Name = "pictureBox58"
        Me.pictureBox58.Size = New System.Drawing.Size(38, 32)
        Me.pictureBox58.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pictureBox58.TabIndex = 505
        Me.pictureBox58.TabStop = False
        '
        'pictureBox59
        '
        Me.pictureBox59.Location = New System.Drawing.Point(597, 219)
        Me.pictureBox59.Name = "pictureBox59"
        Me.pictureBox59.Size = New System.Drawing.Size(38, 32)
        Me.pictureBox59.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pictureBox59.TabIndex = 504
        Me.pictureBox59.TabStop = False
        '
        'pictureBox60
        '
        Me.pictureBox60.Location = New System.Drawing.Point(553, 219)
        Me.pictureBox60.Name = "pictureBox60"
        Me.pictureBox60.Size = New System.Drawing.Size(38, 32)
        Me.pictureBox60.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pictureBox60.TabIndex = 503
        Me.pictureBox60.TabStop = False
        '
        'pictureBox61
        '
        Me.pictureBox61.Location = New System.Drawing.Point(509, 219)
        Me.pictureBox61.Name = "pictureBox61"
        Me.pictureBox61.Size = New System.Drawing.Size(38, 32)
        Me.pictureBox61.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pictureBox61.TabIndex = 502
        Me.pictureBox61.TabStop = False
        '
        'pictureBox62
        '
        Me.pictureBox62.Location = New System.Drawing.Point(465, 219)
        Me.pictureBox62.Name = "pictureBox62"
        Me.pictureBox62.Size = New System.Drawing.Size(38, 32)
        Me.pictureBox62.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pictureBox62.TabIndex = 501
        Me.pictureBox62.TabStop = False
        '
        'pictureBox63
        '
        Me.pictureBox63.Location = New System.Drawing.Point(421, 219)
        Me.pictureBox63.Name = "pictureBox63"
        Me.pictureBox63.Size = New System.Drawing.Size(38, 32)
        Me.pictureBox63.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pictureBox63.TabIndex = 500
        Me.pictureBox63.TabStop = False
        '
        'pictureBox43
        '
        Me.pictureBox43.Location = New System.Drawing.Point(311, 181)
        Me.pictureBox43.Name = "pictureBox43"
        Me.pictureBox43.Size = New System.Drawing.Size(38, 32)
        Me.pictureBox43.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pictureBox43.TabIndex = 499
        Me.pictureBox43.TabStop = False
        '
        'pictureBox44
        '
        Me.pictureBox44.Location = New System.Drawing.Point(267, 181)
        Me.pictureBox44.Name = "pictureBox44"
        Me.pictureBox44.Size = New System.Drawing.Size(38, 32)
        Me.pictureBox44.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pictureBox44.TabIndex = 498
        Me.pictureBox44.TabStop = False
        '
        'pictureBox45
        '
        Me.pictureBox45.Location = New System.Drawing.Point(223, 181)
        Me.pictureBox45.Name = "pictureBox45"
        Me.pictureBox45.Size = New System.Drawing.Size(38, 32)
        Me.pictureBox45.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pictureBox45.TabIndex = 497
        Me.pictureBox45.TabStop = False
        '
        'pictureBox46
        '
        Me.pictureBox46.Location = New System.Drawing.Point(179, 181)
        Me.pictureBox46.Name = "pictureBox46"
        Me.pictureBox46.Size = New System.Drawing.Size(38, 32)
        Me.pictureBox46.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pictureBox46.TabIndex = 496
        Me.pictureBox46.TabStop = False
        '
        'pictureBox47
        '
        Me.pictureBox47.Location = New System.Drawing.Point(135, 181)
        Me.pictureBox47.Name = "pictureBox47"
        Me.pictureBox47.Size = New System.Drawing.Size(38, 32)
        Me.pictureBox47.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pictureBox47.TabIndex = 495
        Me.pictureBox47.TabStop = False
        '
        'pictureBox49
        '
        Me.pictureBox49.InitialImage = CType(resources.GetObject("pictureBox49.InitialImage"), System.Drawing.Image)
        Me.pictureBox49.Location = New System.Drawing.Point(47, 181)
        Me.pictureBox49.Name = "pictureBox49"
        Me.pictureBox49.Size = New System.Drawing.Size(38, 32)
        Me.pictureBox49.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pictureBox49.TabIndex = 494
        Me.pictureBox49.TabStop = False
        '
        'pictureBox36
        '
        Me.pictureBox36.Location = New System.Drawing.Point(311, 219)
        Me.pictureBox36.Name = "pictureBox36"
        Me.pictureBox36.Size = New System.Drawing.Size(38, 32)
        Me.pictureBox36.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pictureBox36.TabIndex = 493
        Me.pictureBox36.TabStop = False
        '
        'pictureBox37
        '
        Me.pictureBox37.Location = New System.Drawing.Point(267, 219)
        Me.pictureBox37.Name = "pictureBox37"
        Me.pictureBox37.Size = New System.Drawing.Size(38, 32)
        Me.pictureBox37.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pictureBox37.TabIndex = 492
        Me.pictureBox37.TabStop = False
        '
        'pictureBox38
        '
        Me.pictureBox38.Location = New System.Drawing.Point(223, 219)
        Me.pictureBox38.Name = "pictureBox38"
        Me.pictureBox38.Size = New System.Drawing.Size(38, 32)
        Me.pictureBox38.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pictureBox38.TabIndex = 491
        Me.pictureBox38.TabStop = False
        '
        'pictureBox39
        '
        Me.pictureBox39.Location = New System.Drawing.Point(179, 219)
        Me.pictureBox39.Name = "pictureBox39"
        Me.pictureBox39.Size = New System.Drawing.Size(38, 32)
        Me.pictureBox39.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pictureBox39.TabIndex = 490
        Me.pictureBox39.TabStop = False
        '
        'pictureBox40
        '
        Me.pictureBox40.Location = New System.Drawing.Point(135, 219)
        Me.pictureBox40.Name = "pictureBox40"
        Me.pictureBox40.Size = New System.Drawing.Size(38, 32)
        Me.pictureBox40.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pictureBox40.TabIndex = 489
        Me.pictureBox40.TabStop = False
        '
        'pictureBox41
        '
        Me.pictureBox41.Location = New System.Drawing.Point(91, 219)
        Me.pictureBox41.Name = "pictureBox41"
        Me.pictureBox41.Size = New System.Drawing.Size(38, 32)
        Me.pictureBox41.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pictureBox41.TabIndex = 488
        Me.pictureBox41.TabStop = False
        '
        'pictureBox42
        '
        Me.pictureBox42.Location = New System.Drawing.Point(47, 219)
        Me.pictureBox42.Name = "pictureBox42"
        Me.pictureBox42.Size = New System.Drawing.Size(38, 32)
        Me.pictureBox42.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pictureBox42.TabIndex = 487
        Me.pictureBox42.TabStop = False
        '
        'pictureBox29
        '
        Me.pictureBox29.Location = New System.Drawing.Point(311, 257)
        Me.pictureBox29.Name = "pictureBox29"
        Me.pictureBox29.Size = New System.Drawing.Size(38, 32)
        Me.pictureBox29.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pictureBox29.TabIndex = 486
        Me.pictureBox29.TabStop = False
        '
        'pictureBox30
        '
        Me.pictureBox30.Location = New System.Drawing.Point(267, 257)
        Me.pictureBox30.Name = "pictureBox30"
        Me.pictureBox30.Size = New System.Drawing.Size(38, 32)
        Me.pictureBox30.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pictureBox30.TabIndex = 485
        Me.pictureBox30.TabStop = False
        '
        'pictureBox31
        '
        Me.pictureBox31.Location = New System.Drawing.Point(223, 257)
        Me.pictureBox31.Name = "pictureBox31"
        Me.pictureBox31.Size = New System.Drawing.Size(38, 32)
        Me.pictureBox31.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pictureBox31.TabIndex = 484
        Me.pictureBox31.TabStop = False
        '
        'pictureBox32
        '
        Me.pictureBox32.Location = New System.Drawing.Point(179, 257)
        Me.pictureBox32.Name = "pictureBox32"
        Me.pictureBox32.Size = New System.Drawing.Size(38, 32)
        Me.pictureBox32.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pictureBox32.TabIndex = 483
        Me.pictureBox32.TabStop = False
        '
        'pictureBox33
        '
        Me.pictureBox33.Location = New System.Drawing.Point(135, 257)
        Me.pictureBox33.Name = "pictureBox33"
        Me.pictureBox33.Size = New System.Drawing.Size(38, 32)
        Me.pictureBox33.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pictureBox33.TabIndex = 482
        Me.pictureBox33.TabStop = False
        '
        'pictureBox34
        '
        Me.pictureBox34.Location = New System.Drawing.Point(91, 257)
        Me.pictureBox34.Name = "pictureBox34"
        Me.pictureBox34.Size = New System.Drawing.Size(38, 32)
        Me.pictureBox34.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pictureBox34.TabIndex = 481
        Me.pictureBox34.TabStop = False
        '
        'pictureBox35
        '
        Me.pictureBox35.Location = New System.Drawing.Point(47, 257)
        Me.pictureBox35.Name = "pictureBox35"
        Me.pictureBox35.Size = New System.Drawing.Size(38, 32)
        Me.pictureBox35.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pictureBox35.TabIndex = 480
        Me.pictureBox35.TabStop = False
        '
        'label5
        '
        Me.label5.AutoSize = True
        Me.label5.Location = New System.Drawing.Point(543, 196)
        Me.label5.Name = "label5"
        Me.label5.Size = New System.Drawing.Size(0, 17)
        Me.label5.TabIndex = 479
        '
        'label1
        '
        Me.label1.AutoSize = True
        Me.label1.Font = New System.Drawing.Font("Cooper Black", 16.2!)
        Me.label1.Location = New System.Drawing.Point(203, 40)
        Me.label1.Name = "label1"
        Me.label1.Size = New System.Drawing.Size(431, 32)
        Me.label1.TabIndex = 478
        Me.label1.Text = "MOVIE SEAT MANAGEMENT"
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.SystemColors.AppWorkspace
        Me.Panel1.Location = New System.Drawing.Point(-75, 477)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(982, 43)
        Me.Panel1.TabIndex = 611
        '
        'SeatManage
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.WindowFrame
        Me.ClientSize = New System.Drawing.Size(768, 622)
        Me.Controls.Add(Me.PictureBox100)
        Me.Controls.Add(Me.PictureBox99)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.button4)
        Me.Controls.Add(Me.pictureBox92)
        Me.Controls.Add(Me.pictureBox93)
        Me.Controls.Add(Me.pictureBox94)
        Me.Controls.Add(Me.pictureBox95)
        Me.Controls.Add(Me.pictureBox96)
        Me.Controls.Add(Me.pictureBox97)
        Me.Controls.Add(Me.pictureBox98)
        Me.Controls.Add(Me.pictureBox22)
        Me.Controls.Add(Me.pictureBox23)
        Me.Controls.Add(Me.pictureBox24)
        Me.Controls.Add(Me.pictureBox25)
        Me.Controls.Add(Me.pictureBox26)
        Me.Controls.Add(Me.pictureBox27)
        Me.Controls.Add(Me.pictureBox28)
        Me.Controls.Add(Me.pictureBox64)
        Me.Controls.Add(Me.pictureBox65)
        Me.Controls.Add(Me.pictureBox66)
        Me.Controls.Add(Me.pictureBox67)
        Me.Controls.Add(Me.pictureBox68)
        Me.Controls.Add(Me.pictureBox69)
        Me.Controls.Add(Me.pictureBox70)
        Me.Controls.Add(Me.pictureBox71)
        Me.Controls.Add(Me.pictureBox72)
        Me.Controls.Add(Me.pictureBox73)
        Me.Controls.Add(Me.pictureBox74)
        Me.Controls.Add(Me.pictureBox75)
        Me.Controls.Add(Me.pictureBox76)
        Me.Controls.Add(Me.pictureBox77)
        Me.Controls.Add(Me.pictureBox78)
        Me.Controls.Add(Me.pictureBox79)
        Me.Controls.Add(Me.pictureBox80)
        Me.Controls.Add(Me.pictureBox81)
        Me.Controls.Add(Me.pictureBox82)
        Me.Controls.Add(Me.pictureBox83)
        Me.Controls.Add(Me.pictureBox84)
        Me.Controls.Add(Me.pictureBox85)
        Me.Controls.Add(Me.pictureBox86)
        Me.Controls.Add(Me.pictureBox87)
        Me.Controls.Add(Me.pictureBox88)
        Me.Controls.Add(Me.pictureBox89)
        Me.Controls.Add(Me.pictureBox90)
        Me.Controls.Add(Me.pictureBox91)
        Me.Controls.Add(Me.pictureBox1)
        Me.Controls.Add(Me.pictureBox2)
        Me.Controls.Add(Me.pictureBox3)
        Me.Controls.Add(Me.pictureBox4)
        Me.Controls.Add(Me.pictureBox5)
        Me.Controls.Add(Me.pictureBox6)
        Me.Controls.Add(Me.pictureBox7)
        Me.Controls.Add(Me.pictureBox8)
        Me.Controls.Add(Me.pictureBox9)
        Me.Controls.Add(Me.pictureBox10)
        Me.Controls.Add(Me.pictureBox11)
        Me.Controls.Add(Me.pictureBox12)
        Me.Controls.Add(Me.pictureBox13)
        Me.Controls.Add(Me.pictureBox14)
        Me.Controls.Add(Me.pictureBox15)
        Me.Controls.Add(Me.pictureBox16)
        Me.Controls.Add(Me.pictureBox17)
        Me.Controls.Add(Me.pictureBox18)
        Me.Controls.Add(Me.pictureBox19)
        Me.Controls.Add(Me.pictureBox20)
        Me.Controls.Add(Me.pictureBox21)
        Me.Controls.Add(Me.pictureBox48)
        Me.Controls.Add(Me.button3)
        Me.Controls.Add(Me.button2)
        Me.Controls.Add(Me.label34)
        Me.Controls.Add(Me.button1)
        Me.Controls.Add(Me.label27)
        Me.Controls.Add(Me.label28)
        Me.Controls.Add(Me.label29)
        Me.Controls.Add(Me.label30)
        Me.Controls.Add(Me.label31)
        Me.Controls.Add(Me.label32)
        Me.Controls.Add(Me.label33)
        Me.Controls.Add(Me.label26)
        Me.Controls.Add(Me.label25)
        Me.Controls.Add(Me.label24)
        Me.Controls.Add(Me.label23)
        Me.Controls.Add(Me.label22)
        Me.Controls.Add(Me.label21)
        Me.Controls.Add(Me.label20)
        Me.Controls.Add(Me.label13)
        Me.Controls.Add(Me.label14)
        Me.Controls.Add(Me.label15)
        Me.Controls.Add(Me.label16)
        Me.Controls.Add(Me.label17)
        Me.Controls.Add(Me.label18)
        Me.Controls.Add(Me.label19)
        Me.Controls.Add(Me.label12)
        Me.Controls.Add(Me.label11)
        Me.Controls.Add(Me.label10)
        Me.Controls.Add(Me.label9)
        Me.Controls.Add(Me.label8)
        Me.Controls.Add(Me.label7)
        Me.Controls.Add(Me.label6)
        Me.Controls.Add(Me.pictureBox50)
        Me.Controls.Add(Me.pictureBox51)
        Me.Controls.Add(Me.pictureBox52)
        Me.Controls.Add(Me.pictureBox53)
        Me.Controls.Add(Me.pictureBox54)
        Me.Controls.Add(Me.pictureBox55)
        Me.Controls.Add(Me.pictureBox56)
        Me.Controls.Add(Me.pictureBox57)
        Me.Controls.Add(Me.pictureBox58)
        Me.Controls.Add(Me.pictureBox59)
        Me.Controls.Add(Me.pictureBox60)
        Me.Controls.Add(Me.pictureBox61)
        Me.Controls.Add(Me.pictureBox62)
        Me.Controls.Add(Me.pictureBox63)
        Me.Controls.Add(Me.pictureBox43)
        Me.Controls.Add(Me.pictureBox44)
        Me.Controls.Add(Me.pictureBox45)
        Me.Controls.Add(Me.pictureBox46)
        Me.Controls.Add(Me.pictureBox47)
        Me.Controls.Add(Me.pictureBox49)
        Me.Controls.Add(Me.pictureBox36)
        Me.Controls.Add(Me.pictureBox37)
        Me.Controls.Add(Me.pictureBox38)
        Me.Controls.Add(Me.pictureBox39)
        Me.Controls.Add(Me.pictureBox40)
        Me.Controls.Add(Me.pictureBox41)
        Me.Controls.Add(Me.pictureBox42)
        Me.Controls.Add(Me.pictureBox29)
        Me.Controls.Add(Me.pictureBox30)
        Me.Controls.Add(Me.pictureBox31)
        Me.Controls.Add(Me.pictureBox32)
        Me.Controls.Add(Me.pictureBox33)
        Me.Controls.Add(Me.pictureBox34)
        Me.Controls.Add(Me.pictureBox35)
        Me.Controls.Add(Me.label5)
        Me.Controls.Add(Me.label1)
        Me.Controls.Add(Me.Panel1)
        Me.Name = "SeatManage"
        Me.Text = "SeatManage"
        CType(Me.PictureBox100, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox99, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pictureBox92, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pictureBox93, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pictureBox94, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pictureBox95, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pictureBox96, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pictureBox97, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pictureBox98, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pictureBox22, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pictureBox23, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pictureBox24, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pictureBox25, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pictureBox26, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pictureBox27, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pictureBox28, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pictureBox64, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pictureBox65, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pictureBox66, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pictureBox67, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pictureBox68, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pictureBox69, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pictureBox70, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pictureBox71, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pictureBox72, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pictureBox73, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pictureBox74, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pictureBox75, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pictureBox76, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pictureBox77, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pictureBox78, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pictureBox79, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pictureBox80, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pictureBox81, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pictureBox82, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pictureBox83, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pictureBox84, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pictureBox85, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pictureBox86, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pictureBox87, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pictureBox88, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pictureBox89, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pictureBox90, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pictureBox91, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pictureBox3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pictureBox4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pictureBox5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pictureBox6, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pictureBox7, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pictureBox8, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pictureBox9, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pictureBox10, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pictureBox11, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pictureBox12, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pictureBox13, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pictureBox14, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pictureBox15, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pictureBox16, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pictureBox17, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pictureBox18, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pictureBox19, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pictureBox20, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pictureBox21, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pictureBox48, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pictureBox50, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pictureBox51, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pictureBox52, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pictureBox53, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pictureBox54, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pictureBox55, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pictureBox56, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pictureBox57, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pictureBox58, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pictureBox59, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pictureBox60, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pictureBox61, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pictureBox62, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pictureBox63, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pictureBox43, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pictureBox44, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pictureBox45, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pictureBox46, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pictureBox47, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pictureBox49, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pictureBox36, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pictureBox37, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pictureBox38, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pictureBox39, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pictureBox40, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pictureBox41, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pictureBox42, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pictureBox29, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pictureBox30, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pictureBox31, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pictureBox32, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pictureBox33, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pictureBox34, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pictureBox35, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Private WithEvents PictureBox100 As PictureBox
    Private WithEvents PictureBox99 As PictureBox
    Friend WithEvents Label3 As Label
    Friend WithEvents Label2 As Label
    Private WithEvents button4 As Button
    Private WithEvents pictureBox92 As PictureBox
    Private WithEvents pictureBox93 As PictureBox
    Private WithEvents pictureBox94 As PictureBox
    Private WithEvents pictureBox95 As PictureBox
    Private WithEvents pictureBox96 As PictureBox
    Private WithEvents pictureBox97 As PictureBox
    Private WithEvents pictureBox98 As PictureBox
    Private WithEvents pictureBox22 As PictureBox
    Private WithEvents pictureBox23 As PictureBox
    Private WithEvents pictureBox24 As PictureBox
    Private WithEvents pictureBox25 As PictureBox
    Private WithEvents pictureBox26 As PictureBox
    Private WithEvents pictureBox27 As PictureBox
    Private WithEvents pictureBox28 As PictureBox
    Private WithEvents pictureBox64 As PictureBox
    Private WithEvents pictureBox65 As PictureBox
    Private WithEvents pictureBox66 As PictureBox
    Private WithEvents pictureBox67 As PictureBox
    Private WithEvents pictureBox68 As PictureBox
    Private WithEvents pictureBox69 As PictureBox
    Private WithEvents pictureBox70 As PictureBox
    Private WithEvents pictureBox71 As PictureBox
    Private WithEvents pictureBox72 As PictureBox
    Private WithEvents pictureBox73 As PictureBox
    Private WithEvents pictureBox74 As PictureBox
    Private WithEvents pictureBox75 As PictureBox
    Private WithEvents pictureBox76 As PictureBox
    Private WithEvents pictureBox77 As PictureBox
    Private WithEvents pictureBox78 As PictureBox
    Private WithEvents pictureBox79 As PictureBox
    Private WithEvents pictureBox80 As PictureBox
    Private WithEvents pictureBox81 As PictureBox
    Private WithEvents pictureBox82 As PictureBox
    Private WithEvents pictureBox83 As PictureBox
    Private WithEvents pictureBox84 As PictureBox
    Private WithEvents pictureBox85 As PictureBox
    Private WithEvents pictureBox86 As PictureBox
    Private WithEvents pictureBox87 As PictureBox
    Private WithEvents pictureBox88 As PictureBox
    Private WithEvents pictureBox89 As PictureBox
    Private WithEvents pictureBox90 As PictureBox
    Private WithEvents pictureBox91 As PictureBox
    Private WithEvents pictureBox1 As PictureBox
    Private WithEvents pictureBox2 As PictureBox
    Private WithEvents pictureBox3 As PictureBox
    Private WithEvents pictureBox4 As PictureBox
    Private WithEvents pictureBox5 As PictureBox
    Private WithEvents pictureBox6 As PictureBox
    Private WithEvents pictureBox7 As PictureBox
    Private WithEvents pictureBox8 As PictureBox
    Private WithEvents pictureBox9 As PictureBox
    Private WithEvents pictureBox10 As PictureBox
    Private WithEvents pictureBox11 As PictureBox
    Private WithEvents pictureBox12 As PictureBox
    Private WithEvents pictureBox13 As PictureBox
    Private WithEvents pictureBox14 As PictureBox
    Private WithEvents pictureBox15 As PictureBox
    Private WithEvents pictureBox16 As PictureBox
    Private WithEvents pictureBox17 As PictureBox
    Private WithEvents pictureBox18 As PictureBox
    Private WithEvents pictureBox19 As PictureBox
    Private WithEvents pictureBox20 As PictureBox
    Private WithEvents pictureBox21 As PictureBox
    Private WithEvents pictureBox48 As PictureBox
    Private WithEvents button3 As Button
    Private WithEvents button2 As Button
    Private WithEvents label34 As Label
    Private WithEvents button1 As Button
    Private WithEvents label27 As Label
    Private WithEvents label28 As Label
    Private WithEvents label29 As Label
    Private WithEvents label30 As Label
    Private WithEvents label31 As Label
    Private WithEvents label32 As Label
    Private WithEvents label33 As Label
    Private WithEvents label26 As Label
    Private WithEvents label25 As Label
    Private WithEvents label24 As Label
    Private WithEvents label23 As Label
    Private WithEvents label22 As Label
    Private WithEvents label21 As Label
    Private WithEvents label20 As Label
    Private WithEvents label13 As Label
    Private WithEvents label14 As Label
    Private WithEvents label15 As Label
    Private WithEvents label16 As Label
    Private WithEvents label17 As Label
    Private WithEvents label18 As Label
    Private WithEvents label19 As Label
    Private WithEvents label12 As Label
    Private WithEvents label11 As Label
    Private WithEvents label10 As Label
    Private WithEvents label9 As Label
    Private WithEvents label8 As Label
    Private WithEvents label7 As Label
    Private WithEvents label6 As Label
    Private WithEvents pictureBox50 As PictureBox
    Private WithEvents pictureBox51 As PictureBox
    Private WithEvents pictureBox52 As PictureBox
    Private WithEvents pictureBox53 As PictureBox
    Private WithEvents pictureBox54 As PictureBox
    Private WithEvents pictureBox55 As PictureBox
    Private WithEvents pictureBox56 As PictureBox
    Private WithEvents pictureBox57 As PictureBox
    Private WithEvents pictureBox58 As PictureBox
    Private WithEvents pictureBox59 As PictureBox
    Private WithEvents pictureBox60 As PictureBox
    Private WithEvents pictureBox61 As PictureBox
    Private WithEvents pictureBox62 As PictureBox
    Private WithEvents pictureBox63 As PictureBox
    Private WithEvents pictureBox43 As PictureBox
    Private WithEvents pictureBox44 As PictureBox
    Private WithEvents pictureBox45 As PictureBox
    Private WithEvents pictureBox46 As PictureBox
    Private WithEvents pictureBox47 As PictureBox
    Private WithEvents pictureBox49 As PictureBox
    Private WithEvents pictureBox36 As PictureBox
    Private WithEvents pictureBox37 As PictureBox
    Private WithEvents pictureBox38 As PictureBox
    Private WithEvents pictureBox39 As PictureBox
    Private WithEvents pictureBox40 As PictureBox
    Private WithEvents pictureBox41 As PictureBox
    Private WithEvents pictureBox42 As PictureBox
    Private WithEvents pictureBox29 As PictureBox
    Private WithEvents pictureBox30 As PictureBox
    Private WithEvents pictureBox31 As PictureBox
    Private WithEvents pictureBox32 As PictureBox
    Private WithEvents pictureBox33 As PictureBox
    Private WithEvents pictureBox34 As PictureBox
    Private WithEvents pictureBox35 As PictureBox
    Private WithEvents label5 As Label
    Private WithEvents label1 As Label
    Friend WithEvents Panel1 As Panel
End Class
