﻿Imports WindowsApp1.Class1
Public Class SeatManage
    Dim greyIcon As New System.Drawing.Bitmap(My.Resources.grey)
    Dim redIcon As New System.Drawing.Bitmap(My.Resources.red)
    Dim greenIcon As New System.Drawing.Bitmap(My.Resources.green)
    Dim delIcon As New System.Drawing.Bitmap(My.Resources.del)


    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        Dim c As Control
        For Each c In Me.Controls
            If TypeOf (c) Is PictureBox Then
                CType(c, PictureBox).Image = greyIcon
                pictureBox21.Image = redIcon
                pictureBox98.Image = redIcon
                PictureBox99.Image = redIcon
                PictureBox100.Image = greyIcon
                pictureBox44.Image = redIcon
                pictureBox52.Image = redIcon
                pictureBox51.Image = redIcon
                pictureBox81.Image = redIcon
                pictureBox27.Image = redIcon
                pictureBox28.Image = redIcon
                pictureBox22.Image = redIcon
                pictureBox77.Image = redIcon
                pictureBox7.Image = redIcon
                pictureBox40.Image = redIcon
                pictureBox10.Image = redIcon
                pictureBox11.Image = redIcon
                pictureBox56.Image = greenIcon
                pictureBox55.Image = greenIcon
                pictureBox54.Image = greenIcon
            End If
        Next
        If Label2.Text = B1 Then
            If label26.Text = C2 Then
                If label19.Text = change2 Then
                    pictureBox56.Image = redIcon
                ElseIf label18.Text = change2 Then
                    pictureBox55.Image = redIcon
                ElseIf label17.Text = change2 Then
                    pictureBox54.Image = redIcon
                End If
            End If
        ElseIf Label3.Text = B1 Then
            If label26.Text = C2 Then
                If label11.Text = change2 Then
                    pictureBox56.Image = greenIcon
                ElseIf label15.Text = change2 Then
                    pictureBox52.Image = greenIcon
                ElseIf label14.Text = change2 Then
                    pictureBox51.Image = greenIcon
                End If
            ElseIf label28.Text = C2 Then
                If label8.Text = change2 Then
                    pictureBox40.Image = greenIcon
                End If
            ElseIf label29.Text = C2 Then
                If label16.Text = change2 Then
                    pictureBox81.Image = greenIcon
                End If
            ElseIf label30.Text = C2 Then
                If label6.Text = change2 Then
                    pictureBox7.Image = greenIcon
                End If
            ElseIf label31.Text = C2 Then
                If label9.Text = change2 Then
                    pictureBox11.Image = greenIcon
                ElseIf label10.Text = change2 Then
                    pictureBox10.Image = greenIcon
                ElseIf label19.Text = change2 Then
                    pictureBox28.Image = greenIcon
                ElseIf label18.Text = change2 Then
                    pictureBox22.Image = greenIcon
                ElseIf label17.Text = change2 Then
                    pictureBox27.Image = greenIcon
                End If
            ElseIf label32.Text = C2 Then
                If label6.Text = change2 Then
                    pictureBox21.Image = greenIcon
                End If
            ElseIf label33.Text = C2 Then
                If label6.Text = change2 Then
                    pictureBox98.Image = greenIcon
                ElseIf label19.Text = change2 Then
                    pictureBox77.Image = greenIcon
                End If
            End If
        End If


        If Label2.Text = B2 Then
            If label27.Text = C3 Then
                If label6.Text = change Then
                    pictureBox49.Image = greenIcon
                ElseIf label7.Text = change Then
                    pictureBox48.Image = greenIcon
                ElseIf label8.Text = change Then
                    pictureBox47.Image = greenIcon
                ElseIf label13.Text = change Then
                    pictureBox50.Image = greenIcon
                ElseIf label9.Text = change Then
                    pictureBox46.Image = greenIcon
                ElseIf label10.Text = change Then
                    pictureBox45.Image = greenIcon
                ElseIf label16.Text = change Then
                    pictureBox53.Image = greenIcon
                ElseIf label12.Text = change Then
                    pictureBox43.Image = greenIcon
                End If
            ElseIf label28.Text = C3 Then
                If label6.Text = change3 Then
                    pictureBox42.Image = greenIcon
                ElseIf label7.Text = change3 Then
                    pictureBox41.Image = greenIcon
                ElseIf label11.Text = change3 Then
                    pictureBox37.Image = greenIcon
                ElseIf label13.Text = change3 Then
                    pictureBox50.Image = greenIcon
                ElseIf label9.Text = change3 Then
                    pictureBox39.Image = greenIcon
                ElseIf label10.Text = change3 Then
                    pictureBox38.Image = greenIcon
                ElseIf label16.Text = change3 Then
                    pictureBox60.Image = greenIcon
                ElseIf label12.Text = change3 Then
                    pictureBox36.Image = greenIcon
                ElseIf label17.Text = change3 Then
                    pictureBox61.Image = greenIcon
                ElseIf label18.Text = change3 Then
                    pictureBox62.Image = greenIcon
                ElseIf label19.Text = change3 Then
                    pictureBox63.Image = greenIcon
                ElseIf label15.Text = change3 Then
                    pictureBox59.Image = greenIcon
                ElseIf label14.Text = change3 Then
                    pictureBox58.Image = greenIcon
                ElseIf label13.Text = change3 Then
                    pictureBox57.Image = delIcon
                End If

            End If
        End If


        If label27.Text = C1 Then
            If label6.Text = change3 Then
                pictureBox49.Image = delIcon
            ElseIf label7.Text = change3 Then
                pictureBox48.Image = delIcon
            ElseIf label8.Text = change3 Then
                pictureBox47.Image = delIcon
            ElseIf label13.Text = change3 Then
                pictureBox50.Image = delIcon
            ElseIf label9.Text = change3 Then
                pictureBox46.Image = delIcon
            ElseIf label10.Text = change3 Then
                pictureBox45.Image = delIcon
            ElseIf label16.Text = change3 Then
                pictureBox53.Image = delIcon
            ElseIf label12.Text = change3 Then
                pictureBox43.Image = delIcon
            End If

        ElseIf label28.Text = C1 Then
            If label6.Text = change3 Then
                pictureBox42.Image = delIcon
            ElseIf label7.Text = change3 Then
                pictureBox41.Image = delIcon
            ElseIf label11.Text = change3 Then
                pictureBox37.Image = delIcon
            ElseIf label13.Text = change3 Then
                pictureBox50.Image = delIcon
            ElseIf label9.Text = change3 Then
                pictureBox39.Image = delIcon
            ElseIf label10.Text = change3 Then
                pictureBox38.Image = delIcon
            ElseIf label16.Text = change3 Then
                pictureBox60.Image = delIcon
            ElseIf label12.Text = change3 Then
                pictureBox36.Image = delIcon
            ElseIf label17.Text = change3 Then
                pictureBox61.Image = delIcon
            ElseIf label18.Text = change3 Then
                pictureBox62.Image = delIcon
            ElseIf label19.Text = change3 Then
                pictureBox63.Image = delIcon
            ElseIf label15.Text = change3 Then
                pictureBox59.Image = delIcon
            ElseIf label14.Text = change3 Then
                pictureBox58.Image = delIcon
            ElseIf label13.Text = change3 Then
                pictureBox57.Image = delIcon
            End If
        End If
    End Sub
    Private Sub button1_Click_1(sender As Object, e As EventArgs) Handles button1.Click
        Me.Close()
        AddSeat.Show()
    End Sub

    Private Sub button2_Click_1(sender As Object, e As EventArgs) Handles button2.Click
        Me.Close()
        EditSeat.Show()
    End Sub

    Private Sub button3_Click_1(sender As Object, e As EventArgs) Handles button3.Click
        Me.Close()
        Delete.Show()
    End Sub

    Private Sub button4_Click(sender As Object, e As EventArgs) Handles button4.Click
        Dim C1 As New System.Drawing.Bitmap(My.Resources.del)
        MsgBox("Save the proggress?", MsgBoxStyle.Information + MsgBoxStyle.OkOnly, "Message!")
        pictureBox49.Image = C1
    End Sub

    Private Sub pictureBox49_Click(sender As Object, e As EventArgs) Handles pictureBox49.Click
        If CType(sender, PictureBox).Image Is greyIcon Then
            SeatID = label6.Text
            SeatRow = label27.Text
            IsBooked = "available"
            Me.Close()
            AddSeat.Show()
        ElseIf CType(sender, PictureBox).Image Is greenIcon Then
            SeatID = label6.Text
            SeatRow = label27.Text
            IsBooked = "available"
            Me.Close()
            EditSeat.Show()
        ElseIf CType(sender, PictureBox).Image Is redIcon Then
            SeatID = label6.Text
            SeatRow = label27.Text
            IsBooked = "Booked"
            Me.Close()
            EditSeat.Show()
        End If
    End Sub

    Private Sub pictureBox48_Click(sender As Object, e As EventArgs) Handles pictureBox48.Click
        If CType(sender, PictureBox).Image Is greyIcon Then
            SeatID = label7.Text
            SeatRow = label27.Text
            IsBooked = "available"
            Me.Close()
            AddSeat.Show()
        ElseIf CType(sender, PictureBox).Image Is greenIcon Then
            SeatID = label7.Text
            SeatRow = label27.Text
            IsBooked = "available"
            Me.Close()
            EditSeat.Show()
        ElseIf CType(sender, PictureBox).Image Is redIcon Then
            SeatID = label7.Text
            SeatRow = label27.Text
            IsBooked = "Booked"
            Me.Close()
            EditSeat.Show()
        End If
    End Sub

    Private Sub pictureBox47_Click(sender As Object, e As EventArgs) Handles pictureBox47.Click
        If CType(sender, PictureBox).Image Is greyIcon Then
            SeatID = label8.Text
            SeatRow = label27.Text
            IsBooked = "available"
            Me.Close()
            AddSeat.Show()
        ElseIf CType(sender, PictureBox).Image Is greenIcon Then
            SeatID = label8.Text
            SeatRow = label27.Text
            IsBooked = "available"
            Me.Close()
            EditSeat.Show()
        ElseIf CType(sender, PictureBox).Image Is redIcon Then
            SeatID = label8.Text
            SeatRow = label27.Text
            IsBooked = "Booked"
            Me.Close()
            EditSeat.Show()
        End If
    End Sub

    Private Sub pictureBox46_Click(sender As Object, e As EventArgs) Handles pictureBox46.Click
        If CType(sender, PictureBox).Image Is greyIcon Then
            SeatID = label9.Text
            SeatRow = label27.Text
            IsBooked = "available"
            Me.Close()
            AddSeat.Show()
        ElseIf CType(sender, PictureBox).Image Is greenIcon Then
            SeatID = label9.Text
            SeatRow = label27.Text
            IsBooked = "available"
            Me.Close()
            EditSeat.Show()
        ElseIf CType(sender, PictureBox).Image Is redIcon Then
            SeatID = label9.Text
            SeatRow = label27.Text
            IsBooked = "Booked"
            Me.Close()
            EditSeat.Show()
        End If
    End Sub

    Private Sub pictureBox45_Click(sender As Object, e As EventArgs) Handles pictureBox45.Click
        If CType(sender, PictureBox).Image Is greyIcon Then
            SeatID = label10.Text
            SeatRow = label27.Text
            IsBooked = "available"
            Me.Close()
            AddSeat.Show()
        ElseIf CType(sender, PictureBox).Image Is greenIcon Then
            SeatID = label10.Text
            SeatRow = label27.Text
            IsBooked = "available"
            Me.Close()
            EditSeat.Show()
        ElseIf CType(sender, PictureBox).Image Is redIcon Then
            SeatID = label10.Text
            SeatRow = label27.Text
            IsBooked = "Booked"
            Me.Close()
            EditSeat.Show()
        End If
    End Sub

    Private Sub pictureBox44_Click(sender As Object, e As EventArgs) Handles pictureBox44.Click
        If CType(sender, PictureBox).Image Is greyIcon Then
            SeatID = label11.Text
            SeatRow = label27.Text
            IsBooked = "available"
            Me.Close()
            AddSeat.Show()
        ElseIf CType(sender, PictureBox).Image Is greenIcon Then
            SeatID = label11.Text
            SeatRow = label27.Text
            IsBooked = "available"
            Me.Close()
            EditSeat.Show()
        ElseIf CType(sender, PictureBox).Image Is redIcon Then
            SeatID = label11.Text
            SeatRow = label27.Text
            IsBooked = "Booked"
            Me.Close()
            EditSeat.Show()
        End If
    End Sub

    Private Sub pictureBox43_Click(sender As Object, e As EventArgs) Handles pictureBox43.Click
        If CType(sender, PictureBox).Image Is greyIcon Then
            SeatID = label12.Text
            SeatRow = label27.Text
            IsBooked = "available"
            Me.Close()
            AddSeat.Show()
        ElseIf CType(sender, PictureBox).Image Is greenIcon Then
            SeatID = label12.Text
            SeatRow = label27.Text
            IsBooked = "available"
            Me.Close()
            EditSeat.Show()
        ElseIf CType(sender, PictureBox).Image Is redIcon Then
            SeatID = label12.Text
            SeatRow = label27.Text
            IsBooked = "Booked"
            Me.Close()
            EditSeat.Show()
        End If
    End Sub

    Private Sub pictureBox42_Click(sender As Object, e As EventArgs) Handles pictureBox42.Click
        If CType(sender, PictureBox).Image Is greyIcon Then
            SeatID = label6.Text
            SeatRow = label28.Text
            IsBooked = "available"
            Me.Close()
            AddSeat.Show()
        ElseIf CType(sender, PictureBox).Image Is greenIcon Then
            SeatID = label6.Text
            SeatRow = label28.Text
            IsBooked = "available"
            Me.Close()
            EditSeat.Show()
        ElseIf CType(sender, PictureBox).Image Is redIcon Then
            SeatID = label6.Text
            SeatRow = label28.Text
            IsBooked = "Booked"
            Me.Close()
            EditSeat.Show()
        End If
    End Sub

    Private Sub pictureBox41_Click(sender As Object, e As EventArgs) Handles pictureBox41.Click
        If CType(sender, PictureBox).Image Is greyIcon Then
            SeatID = label7.Text
            SeatRow = label28.Text
            IsBooked = "available"
            Me.Close()
            AddSeat.Show()
        ElseIf CType(sender, PictureBox).Image Is greenIcon Then
            SeatID = label7.Text
            SeatRow = label28.Text
            IsBooked = "available"
            Me.Close()
            EditSeat.Show()
        ElseIf CType(sender, PictureBox).Image Is redIcon Then
            SeatID = label7.Text
            SeatRow = label28.Text
            IsBooked = "Booked"
            Me.Close()
            EditSeat.Show()
        End If
    End Sub
    Private Sub pictureBox40_Click(sender As Object, e As EventArgs) Handles pictureBox40.Click
        If CType(sender, PictureBox).Image Is greyIcon Then
            SeatID = label8.Text
            SeatRow = label28.Text
            IsBooked = "available"
            Me.Close()
            AddSeat.Show()
        ElseIf CType(sender, PictureBox).Image Is greenIcon Then
            SeatID = label8.Text
            SeatRow = label28.Text
            IsBooked = "available"
            Me.Close()
            EditSeat.Show()
        ElseIf CType(sender, PictureBox).Image Is redIcon Then
            SeatID = label8.Text
            SeatRow = label28.Text
            IsBooked = "Booked"
            Me.Close()
            EditSeat.Show()
        End If
    End Sub

    Private Sub pictureBox39_Click(sender As Object, e As EventArgs) Handles pictureBox39.Click
        If CType(sender, PictureBox).Image Is greyIcon Then
            SeatID = label9.Text
            SeatRow = label28.Text
            IsBooked = "available"
            Me.Close()
            AddSeat.Show()
        ElseIf CType(sender, PictureBox).Image Is greenIcon Then
            SeatID = label9.Text
            SeatRow = label28.Text
            IsBooked = "available"
            Me.Close()
            EditSeat.Show()
        ElseIf CType(sender, PictureBox).Image Is redIcon Then
            SeatID = label9.Text
            SeatRow = label28.Text
            IsBooked = "Booked"
            Me.Close()
            EditSeat.Show()
        End If
    End Sub

    Private Sub pictureBox38_Click(sender As Object, e As EventArgs) Handles pictureBox38.Click
        If CType(sender, PictureBox).Image Is greyIcon Then
            SeatID = label10.Text
            SeatRow = label28.Text
            IsBooked = "available"
            Me.Close()
            AddSeat.Show()
        ElseIf CType(sender, PictureBox).Image Is greenIcon Then
            SeatID = label10.Text
            SeatRow = label28.Text
            IsBooked = "available"
            Me.Close()
            EditSeat.Show()
        ElseIf CType(sender, PictureBox).Image Is redIcon Then
            SeatID = label10.Text
            SeatRow = label28.Text
            IsBooked = "Booked"
            Me.Close()
            EditSeat.Show()
        End If
    End Sub

    Private Sub pictureBox37_Click(sender As Object, e As EventArgs) Handles pictureBox37.Click
        If CType(sender, PictureBox).Image Is greyIcon Then
            SeatID = label11.Text
            SeatRow = label28.Text
            IsBooked = "available"
            Me.Close()
            AddSeat.Show()
        ElseIf CType(sender, PictureBox).Image Is greenIcon Then
            SeatID = label11.Text
            SeatRow = label28.Text
            IsBooked = "available"
            Me.Close()
            EditSeat.Show()
        ElseIf CType(sender, PictureBox).Image Is redIcon Then
            SeatID = label11.Text
            SeatRow = label28.Text
            IsBooked = "Booked"
            Me.Close()
            EditSeat.Show()
        End If
    End Sub

    Private Sub pictureBox36_Click(sender As Object, e As EventArgs) Handles pictureBox36.Click
        If CType(sender, PictureBox).Image Is greyIcon Then
            SeatID = label12.Text
            SeatRow = label28.Text
            IsBooked = "available"
            Me.Close()
            AddSeat.Show()
        ElseIf CType(sender, PictureBox).Image Is greenIcon Then
            SeatID = label12.Text
            SeatRow = label28.Text
            IsBooked = "available"
            Me.Close()
            EditSeat.Show()
        ElseIf CType(sender, PictureBox).Image Is redIcon Then
            SeatID = label12.Text
            SeatRow = label28.Text
            IsBooked = "Booked"
            Me.Close()
            EditSeat.Show()
        End If
    End Sub

    Private Sub pictureBox56_Click(sender As Object, e As EventArgs) Handles pictureBox56.Click
        If CType(sender, PictureBox).Image Is greyIcon Then
            SeatID = label19.Text
            SeatRow = label26.Text
            IsBooked = "available"
            Me.Close()
            AddSeat.Show()
        ElseIf CType(sender, PictureBox).Image Is greenIcon Then
            SeatID = label19.Text
            SeatRow = label26.Text
            IsBooked = "available"
            Me.Close()
            EditSeat.Show()
        ElseIf CType(sender, PictureBox).Image Is redIcon Then
            SeatID = label19.Text
            SeatRow = label26.Text
            IsBooked = "Booked"
            Me.Close()
            EditSeat.Show()
        End If
    End Sub

    Private Sub pictureBox55_Click(sender As Object, e As EventArgs) Handles pictureBox55.Click
        If CType(sender, PictureBox).Image Is greyIcon Then
            SeatID = label18.Text
            SeatRow = label26.Text
            IsBooked = "available"
            Me.Close()
            AddSeat.Show()
        ElseIf CType(sender, PictureBox).Image Is greenIcon Then
            SeatID = label18.Text
            SeatRow = label26.Text
            IsBooked = "available"
            Me.Close()
            EditSeat.Show()
        ElseIf CType(sender, PictureBox).Image Is redIcon Then
            SeatID = label18.Text
            SeatRow = label26.Text
            IsBooked = "Booked"
            Me.Close()
            EditSeat.Show()
        End If
    End Sub

    Private Sub pictureBox54_Click(sender As Object, e As EventArgs) Handles pictureBox54.Click
        If CType(sender, PictureBox).Image Is greyIcon Then
            SeatID = label17.Text
            SeatRow = label26.Text
            IsBooked = "available"
            Me.Close()
            AddSeat.Show()
        ElseIf CType(sender, PictureBox).Image Is greenIcon Then
            SeatID = label17.Text
            SeatRow = label26.Text
            IsBooked = "available"
            Me.Close()
            EditSeat.Show()
        ElseIf CType(sender, PictureBox).Image Is redIcon Then
            SeatID = label17.Text
            SeatRow = label26.Text
            IsBooked = "Booked"
            Me.Close()
            EditSeat.Show()
        End If
    End Sub

    Private Sub pictureBox53_Click(sender As Object, e As EventArgs) Handles pictureBox53.Click
        If CType(sender, PictureBox).Image Is greyIcon Then
            SeatID = label16.Text
            SeatRow = label26.Text
            IsBooked = "available"
            Me.Close()
            AddSeat.Show()
        ElseIf CType(sender, PictureBox).Image Is greenIcon Then
            SeatID = label16.Text
            SeatRow = label26.Text
            IsBooked = "available"
            Me.Close()
            EditSeat.Show()
        ElseIf CType(sender, PictureBox).Image Is redIcon Then
            SeatID = label16.Text
            SeatRow = label26.Text
            IsBooked = "Booked"
            Me.Close()
            EditSeat.Show()
        End If
    End Sub

    Private Sub pictureBox52_Click(sender As Object, e As EventArgs) Handles pictureBox52.Click
        If CType(sender, PictureBox).Image Is greyIcon Then
            SeatID = label15.Text
            SeatRow = label26.Text
            IsBooked = "available"
            Me.Close()
            AddSeat.Show()
        ElseIf CType(sender, PictureBox).Image Is greenIcon Then
            SeatID = label15.Text
            SeatRow = label26.Text
            IsBooked = "available"
            Me.Close()
            EditSeat.Show()
        ElseIf CType(sender, PictureBox).Image Is redIcon Then
            SeatID = label15.Text
            SeatRow = label26.Text
            IsBooked = "Booked"
            Me.Close()
            EditSeat.Show()
        End If
    End Sub

    Private Sub pictureBox51_Click(sender As Object, e As EventArgs) Handles pictureBox51.Click
        If CType(sender, PictureBox).Image Is greyIcon Then
            SeatID = label14.Text
            SeatRow = label26.Text
            IsBooked = "available"
            Me.Close()
            AddSeat.Show()
        ElseIf CType(sender, PictureBox).Image Is greenIcon Then
            SeatID = label14.Text
            SeatRow = label26.Text
            IsBooked = "available"
            Me.Close()
            EditSeat.Show()
        ElseIf CType(sender, PictureBox).Image Is redIcon Then
            SeatID = label14.Text
            SeatRow = label26.Text
            IsBooked = "Booked"
            Me.Close()
            EditSeat.Show()
        End If
    End Sub

    Private Sub pictureBox50_Click(sender As Object, e As EventArgs) Handles pictureBox50.Click
        If CType(sender, PictureBox).Image Is greyIcon Then
            SeatID = label13.Text
            SeatRow = label26.Text
            IsBooked = "available"
            Me.Close()
            AddSeat.Show()
        ElseIf CType(sender, PictureBox).Image Is greenIcon Then
            SeatID = label13.Text
            SeatRow = label26.Text
            IsBooked = "available"
            Me.Close()
            EditSeat.Show()
        ElseIf CType(sender, PictureBox).Image Is redIcon Then
            SeatID = label13.Text
            SeatRow = label26.Text
            IsBooked = "Booked"
            Me.Close()
            EditSeat.Show()
        End If
    End Sub

    Private Sub pictureBox63_Click(sender As Object, e As EventArgs) Handles pictureBox63.Click
        If CType(sender, PictureBox).Image Is greyIcon Then
            SeatID = label19.Text
            SeatRow = label25.Text
            IsBooked = "available"
            Me.Close()
            AddSeat.Show()
        ElseIf CType(sender, PictureBox).Image Is greenIcon Then
            SeatID = label19.Text
            SeatRow = label25.Text
            IsBooked = "available"
            Me.Close()
            EditSeat.Show()
        ElseIf CType(sender, PictureBox).Image Is redIcon Then
            SeatID = label19.Text
            SeatRow = label25.Text
            IsBooked = "Booked"
            Me.Close()
            EditSeat.Show()
        End If
    End Sub

    Private Sub pictureBox62_Click(sender As Object, e As EventArgs) Handles pictureBox62.Click
        If CType(sender, PictureBox).Image Is greyIcon Then
            SeatID = label18.Text
            SeatRow = label25.Text
            IsBooked = "available"
            Me.Close()
            AddSeat.Show()
        ElseIf CType(sender, PictureBox).Image Is greenIcon Then
            SeatID = label18.Text
            SeatRow = label25.Text
            IsBooked = "available"
            Me.Close()
            EditSeat.Show()
        ElseIf CType(sender, PictureBox).Image Is redIcon Then
            SeatID = label18.Text
            SeatRow = label25.Text
            IsBooked = "Booked"
            Me.Close()
            EditSeat.Show()
        End If
    End Sub

    Private Sub pictureBox61_Click(sender As Object, e As EventArgs) Handles pictureBox61.Click
        If CType(sender, PictureBox).Image Is greyIcon Then
            SeatID = label17.Text
            SeatRow = label25.Text
            IsBooked = "available"
            Me.Close()
            AddSeat.Show()
        ElseIf CType(sender, PictureBox).Image Is greenIcon Then
            SeatID = label17.Text
            SeatRow = label25.Text
            IsBooked = "available"
            Me.Close()
            EditSeat.Show()
        ElseIf CType(sender, PictureBox).Image Is redIcon Then
            SeatID = label17.Text
            SeatRow = label25.Text
            IsBooked = "Booked"
            Me.Close()
            EditSeat.Show()
        End If
    End Sub

    Private Sub pictureBox60_Click(sender As Object, e As EventArgs) Handles pictureBox60.Click
        If CType(sender, PictureBox).Image Is greyIcon Then
            SeatID = label16.Text
            SeatRow = label25.Text
            IsBooked = "available"
            Me.Close()
            AddSeat.Show()
        ElseIf CType(sender, PictureBox).Image Is greenIcon Then
            SeatID = label16.Text
            SeatRow = label25.Text
            IsBooked = "available"
            Me.Close()
            EditSeat.Show()
        ElseIf CType(sender, PictureBox).Image Is redIcon Then
            SeatID = label16.Text
            SeatRow = label25.Text
            IsBooked = "Booked"
            Me.Close()
            EditSeat.Show()
        End If
    End Sub

    Private Sub pictureBox59_Click(sender As Object, e As EventArgs) Handles pictureBox59.Click
        If CType(sender, PictureBox).Image Is greyIcon Then
            SeatID = label15.Text
            SeatRow = label25.Text
            IsBooked = "available"
            Me.Close()
            AddSeat.Show()
        ElseIf CType(sender, PictureBox).Image Is greenIcon Then
            SeatID = label15.Text
            SeatRow = label25.Text
            IsBooked = "available"
            Me.Close()
            EditSeat.Show()
        ElseIf CType(sender, PictureBox).Image Is redIcon Then
            SeatID = label15.Text
            SeatRow = label25.Text
            IsBooked = "Booked"
            Me.Close()
            EditSeat.Show()
        End If
    End Sub

    Private Sub pictureBox58_Click(sender As Object, e As EventArgs) Handles pictureBox58.Click
        If CType(sender, PictureBox).Image Is greyIcon Then
            SeatID = label14.Text
            SeatRow = label25.Text
            IsBooked = "available"
            Me.Close()
            AddSeat.Show()
        ElseIf CType(sender, PictureBox).Image Is greenIcon Then
            SeatID = label14.Text
            SeatRow = label25.Text
            IsBooked = "available"
            Me.Close()
            EditSeat.Show()
        ElseIf CType(sender, PictureBox).Image Is redIcon Then
            SeatID = label14.Text
            SeatRow = label25.Text
            IsBooked = "Booked"
            Me.Close()
            EditSeat.Show()
        End If
    End Sub

    Private Sub pictureBox57_Click(sender As Object, e As EventArgs) Handles pictureBox57.Click
        If CType(sender, PictureBox).Image Is greyIcon Then
            SeatID = label13.Text
            SeatRow = label25.Text
            IsBooked = "available"
            Me.Close()
            AddSeat.Show()
        ElseIf CType(sender, PictureBox).Image Is greenIcon Then
            SeatID = label13.Text
            SeatRow = label25.Text
            IsBooked = "available"
            Me.Close()
            EditSeat.Show()
        ElseIf CType(sender, PictureBox).Image Is redIcon Then
            SeatID = label13.Text
            SeatRow = label25.Text
            IsBooked = "Booked"
            Me.Close()
            EditSeat.Show()
        End If
    End Sub
End Class
