﻿Imports WindowsApp1.Class1
Public Class AddSeat


    Private Sub AddSeat_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        textBox1.Text = SeatID
        textBox2.Text = SeatRow
        TextBox3.Text = IsBooked
        If TextBox3.Text = "Booked" Then
            B2 = TextBox3.Text
            Me.Close()
            SeatManage.Show()
        End If
    End Sub

    Private Sub button2_Click(sender As Object, e As EventArgs) Handles button2.Click
        Dim dialog As DialogResult
        dialog = MessageBox.Show("Do You really want to close the Progress", "Exit", MessageBoxButtons.YesNo)
        If dialog = vbYes Then
            Me.Close()
            SeatManage.Show()
        End If
    End Sub

    Private Sub button1_Click(sender As Object, e As EventArgs) Handles button1.Click
        If TextBox3.Text = "Booked" Then
            B2 = TextBox3.Text
            If textBox2.Text = "G" Then
                C3 = textBox2.Text
                If textBox1.Text = "1" Then
                    change = textBox1.Text
                    Me.Close()
                    SeatManage.Show()
                ElseIf textBox1.Text = "2" Then
                    change = textBox1.Text
                    Me.Close()
                    SeatManage.Show()
                ElseIf textBox1.Text = "3" Then
                    change = textBox1.Text
                    Me.Close()
                    SeatManage.Show()
                ElseIf textBox1.Text = "4" Then
                    change = textBox1.Text
                    Me.Close()
                    SeatManage.Show()
                ElseIf textBox1.Text = "5" Then
                    change = textBox1.Text
                    Me.Close()
                    SeatManage.Show()
                ElseIf textBox1.Text = "7" Then
                    change = textBox1.Text
                    Me.Close()
                    SeatManage.Show()
                ElseIf textBox1.Text = "11" Then
                    change = textBox1.Text
                    Me.Close()
                    SeatManage.Show()
                ElseIf textBox1.Text = "14" Then
                    change = textBox1.Text
                    Me.Close()
                    SeatManage.Show()
                End If
            ElseIf textBox2.Text = "F" Then
                C3 = textBox2.Text
                If textBox1.Text = "1" Then
                    change = textBox1.Text
                    Me.Close()
                    SeatManage.Show()
                ElseIf textBox1.Text = "2" Then
                    change = textBox1.Text
                    Me.Close()
                    SeatManage.Show()
                ElseIf textBox1.Text = "6" Then
                    change = textBox1.Text
                    Me.Close()
                    SeatManage.Show()
                ElseIf textBox1.Text = "4" Then
                    change = textBox1.Text
                    Me.Close()
                    SeatManage.Show()
                ElseIf textBox1.Text = "5" Then
                    change = textBox1.Text
                    Me.Close()
                    SeatManage.Show()
                ElseIf textBox1.Text = "7" Then
                    change = textBox1.Text
                    Me.Close()
                    SeatManage.Show()
                ElseIf textBox1.Text = "8" Then
                    change = textBox1.Text
                    Me.Close()
                    SeatManage.Show()
                ElseIf textBox1.Text = "9" Then
                    change = textBox1.Text
                    Me.Close()
                    SeatManage.Show()
                ElseIf textBox1.Text = "10" Then
                    change = textBox1.Text
                    Me.Close()
                    SeatManage.Show()
                ElseIf textBox1.Text = "11" Then
                    change = textBox1.Text
                    Me.Close()
                    SeatManage.Show()
                ElseIf textBox1.Text = "12" Then
                    change = textBox1.Text
                    Me.Close()
                    SeatManage.Show()
                ElseIf textBox1.Text = "13" Then
                    change = textBox1.Text
                    Me.Close()
                    SeatManage.Show()
                ElseIf textBox1.Text = "14" Then
                    change = textBox1.Text
                    Me.Close()
                    SeatManage.Show()
                End If
            End If
        End If
    End Sub
End Class