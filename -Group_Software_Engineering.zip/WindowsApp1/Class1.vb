﻿Public Class Class1
    Public Shared SeatID As String
    Public Shared SeatRow As String
    Public Shared IsBooked As String
    Public Shared change As String
    Public Shared change2 As String
    Public Shared change3 As String
    Public Shared C1 As String
    Public Shared C2 As String
    Public Shared C3 As String
    Public Shared B1 As String
    Public Shared B2 As String
    Public Shared A1 As String

    Public Shared Username As String
    Public Shared Name As String
    Public Shared Phone As String
    Public Shared Email As String
    Public Shared Password As String
    Public Shared ConfirmPassword As String
End Class
