﻿Public Class Class1
    Public Shared SeatID As String
    Public Shared SeatRow As String
    Public Shared IsBooked As String
End Class
